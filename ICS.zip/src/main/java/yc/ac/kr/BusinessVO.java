package yc.ac.kr;

public class BusinessVO {
	
	private String b_num;
	private String b_name;
	private String b_loc;
	
	public String getB_num() {
		return b_num;
	}
	public void setB_num(String b_num) {
		this.b_num = b_num;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_loc() {
		return b_loc;
	}
	public void setB_loc(String b_loc) {
		this.b_loc = b_loc;
	}
	
}
