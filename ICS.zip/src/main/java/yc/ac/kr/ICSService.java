package yc.ac.kr;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Component;

import com.nexacro17.xapi.data.DataSet;
import com.nexacro17.xapi.data.DataTypes;
import com.nexacro17.xapi.data.PlatformData;

@Component
public class ICSService implements ICSServiceImp {
	
	private List<BusinessVO> businessVO = new ArrayList<BusinessVO>();
	private List<ItemVO> itemVO = new ArrayList<ItemVO>();
	private List<WarehouseVO> warehouseVO = new ArrayList<WarehouseVO>();
	private List<BuyhistoryVO> buyhistoryVO = new ArrayList<BuyhistoryVO>();
	private List<UitemVO> uitemVO = new ArrayList<UitemVO>();
	private List<PaymentVO> paymentVO = new ArrayList<PaymentVO>();
	private List<PayhistoryVO> payhistoryVO = new ArrayList<PayhistoryVO>();
	private List<CountfinishVO> countfinishVO = new ArrayList<CountfinishVO>();
	private List<MoneyfinishVO> moneyfinishVO = new ArrayList<MoneyfinishVO>();
	
	@Inject
	private ICSDao icsdao;

	@Override
	public PlatformData loadbusiness() {
		// TODO Auto-generated method stub		
		businessVO = icsdao.loadbusiness();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("����ڹ�ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.STRING, (short)50);
		
		for(int i=0; i<businessVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "����ڹ�ȣ", businessVO.get(i).getB_num());
			ds.set(row, "�ŷ�ó��", businessVO.get(i).getB_name());
			ds.set(row, "����", businessVO.get(i).getB_loc());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public int addbusiness(BusinessVO businessVO) {
		// TODO Auto-generated method stub		
		
		return icsdao.addbusiness(businessVO);
	}

	@Override
	public PlatformData searchbusiness(String parameter) {
		// TODO Auto-generated method stub
		String kind = parameter.split("/")[0];
		String value = parameter.split("/")[1];
		
		if(kind.equals("b_num")) {
			businessVO = icsdao.searchb_num(value);
		}else if(kind.equals("b_name")) {
			businessVO = icsdao.searchb_name(value);
		}else if(kind.equals("b_loc")){
			businessVO = icsdao.searchb_loc(value);
		}		

		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("����ڹ�ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.STRING, (short)50);
		
		for(int i=0; i<businessVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "����ڹ�ȣ", businessVO.get(i).getB_num());
			ds.set(row, "�ŷ�ó��", businessVO.get(i).getB_name());
			ds.set(row, "����", businessVO.get(i).getB_loc());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public int deletebusiness(String parameter) {
		// TODO Auto-generated method stub
		return icsdao.deletebusiness(parameter);
	}

	@Override
	public PlatformData loaditem() {
		// TODO Auto-generated method stub
		itemVO = icsdao.loaditem();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("����ڹ�ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("�ܰ�", DataTypes.INT);
		ds.addColumn("EA", DataTypes.STRING, (short)50);
		
		for(int i=0; i<itemVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "��ǰ��ȣ", itemVO.get(i).getI_num());
			ds.set(row, "��ǰ��", itemVO.get(i).getI_name());
			ds.set(row, "����ڹ�ȣ", itemVO.get(i).getB_num());
			ds.set(row, "�ŷ�ó��", itemVO.get(i).getB_name());
			ds.set(row, "�ܰ�", itemVO.get(i).getPrice());
			ds.set(row, "EA", itemVO.get(i).getEa());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public int additem(ItemVO itemVO) {
		// TODO Auto-generated method stub
		return icsdao.additem(itemVO);
	}

	@Override
	public int deleteitem(String parameter) {
		// TODO Auto-generated method stub
		return icsdao.deleteitem(parameter);
	}

	@Override
	public PlatformData searchitem(String parameter) {
		// TODO Auto-generated method stub
		String kind = parameter.split("/")[0];
		String value = parameter.split("/")[1];
		
		if(kind.equals("i_num")) {
			itemVO = icsdao.searchi_num(value);
		}else if(kind.equals("i_name")) {
			itemVO = icsdao.searchi_name(value);
		}else if(kind.equals("b_num")){
			itemVO = icsdao.searchib_num(value);
		}else if(kind.equals("b_name")){
			itemVO = icsdao.searchib_name(value);
		}			

		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("����ڹ�ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("�ܰ�", DataTypes.INT);
		ds.addColumn("EA", DataTypes.STRING, (short)50);
		
		for(int i=0; i<itemVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "��ǰ��ȣ", itemVO.get(i).getI_num());
			ds.set(row, "��ǰ��", itemVO.get(i).getI_name());
			ds.set(row, "����ڹ�ȣ", itemVO.get(i).getB_num());
			ds.set(row, "�ŷ�ó��", itemVO.get(i).getB_name());
			ds.set(row, "�ܰ�", itemVO.get(i).getPrice());
			ds.set(row, "EA", itemVO.get(i).getEa());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public int addwarehouse(IcsVO icsVO) {
		// TODO Auto-generated method stub
		int count = icsdao.existwarehouse(icsVO);
		
		if(count >= 1) {
			return icsdao.updatewarehouse(icsVO);
		}else {
			return icsdao.addwarehouse(icsVO);
		}
	}

	@Override
	public int addpayment(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return icsdao.addpayment(icsVO);
	}

	@Override
	public int addbuyhistory(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return icsdao.addbuyhistory(icsVO);
	}

	@Override
	public PlatformData loadwarehouse() {
		// TODO Auto-generated method stub
		warehouseVO = icsdao.loadwarehouse();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("EA", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.INT);
		ds.addColumn("�ֱ��������", DataTypes.STRING, (short)50);
		
		
		for(int i=0; i<warehouseVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", warehouseVO.get(i).getId());
			ds.set(row, "��ǰ��ȣ", warehouseVO.get(i).getI_num());
			ds.set(row, "��ǰ��", warehouseVO.get(i).getI_name());
			ds.set(row, "EA", warehouseVO.get(i).getEa());
			ds.set(row, "����", warehouseVO.get(i).getCount());
			ds.set(row, "�ֱ��������", warehouseVO.get(i).getL_date());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public PlatformData searchwarehouse(String parameter) throws ParseException {
		// TODO Auto-generated method stub
		DateVO dateVO = new DateVO();
		
		String[] stra = parameter.split("/");
		String kind = stra[0];
		String value = stra[1];
				
		if(kind.equals("i_num")) {
			warehouseVO = icsdao.searchwi_num(value);
		}else if(kind.equals("i_name")) {			
			warehouseVO = icsdao.searchwi_name(value);
		}else if(kind.equals("date")) {
			String from = value.split("~")[0];
			String to = value.split("~")[1];
			
			dateVO.setFrom(from);
			dateVO.setTo(to);

			warehouseVO = icsdao.searchwdate(dateVO);
		}		
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("EA", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.INT);
		ds.addColumn("�ֱ��������", DataTypes.STRING, (short)50);
		
		for(int i=0; i<warehouseVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", warehouseVO.get(i).getId());
			ds.set(row, "��ǰ��ȣ", warehouseVO.get(i).getI_num());
			ds.set(row, "��ǰ��", warehouseVO.get(i).getI_name());
			ds.set(row, "EA", warehouseVO.get(i).getEa());
			ds.set(row, "����", warehouseVO.get(i).getCount());
			ds.set(row, "�ֱ��������", warehouseVO.get(i).getL_date());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	public PlatformData loadbuyhistory() {
		// TODO Auto-generated method stub
		buyhistoryVO = icsdao.loadbuyhistory();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.INT);
		ds.addColumn("�Ѱ���", DataTypes.INT);
		ds.addColumn("������", DataTypes.STRING, (short)50);
		ds.addColumn("�����", DataTypes.STRING, (short)50);
		
		for(int i=0; i<buyhistoryVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", buyhistoryVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", buyhistoryVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", buyhistoryVO.get(i).getI_num());
			ds.set(row, "��ǰ��", buyhistoryVO.get(i).getI_name());
			ds.set(row, "����", buyhistoryVO.get(i).getCount());
			ds.set(row, "�Ѱ���", buyhistoryVO.get(i).getPrice() * buyhistoryVO.get(i).getCount());
			ds.set(row, "������", buyhistoryVO.get(i).getB_date());
			ds.set(row, "�����", buyhistoryVO.get(i).getWho());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	public PlatformData searchbuyhistory(String parameter) {
		// TODO Auto-generated method stub
		DateVO dateVO = new DateVO();
		
		String[] stra = parameter.split("/");
		String kind = stra[0];
		String value = stra[1];
				
		if(kind.equals("i_num")) {
			buyhistoryVO = icsdao.searchbhi_num(value);
		}else if(kind.equals("i_name")) {			
			buyhistoryVO = icsdao.searchbhi_name(value);
		}else if(kind.equals("b_name")) {
			buyhistoryVO = icsdao.searchbhb_name(value);
		}else if(kind.equals("date")) {
			String from = value.split("~")[0];
			String to = value.split("~")[1];
			
			dateVO.setFrom(from);
			dateVO.setTo(to);

			buyhistoryVO = icsdao.searchbhdate(dateVO);
		}else if(kind.equals("who")) {
			buyhistoryVO = icsdao.searchbhwho(value);
		}
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.INT);
		ds.addColumn("�Ѱ���", DataTypes.INT);
		ds.addColumn("������", DataTypes.STRING, (short)50);
		ds.addColumn("�����", DataTypes.STRING, (short)50);
		
		for(int i=0; i<buyhistoryVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", buyhistoryVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", buyhistoryVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", buyhistoryVO.get(i).getI_num());
			ds.set(row, "��ǰ��", buyhistoryVO.get(i).getI_name());
			ds.set(row, "����", buyhistoryVO.get(i).getCount());
			ds.set(row, "�Ѱ���", buyhistoryVO.get(i).getPrice() * buyhistoryVO.get(i).getCount());
			ds.set(row, "������", buyhistoryVO.get(i).getB_date());
			ds.set(row, "�����", buyhistoryVO.get(i).getWho());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}
	
	public PlatformData searchsellhistory(String parameter) {
		// TODO Auto-generated method stub
		DateVO dateVO = new DateVO();
		
		String[] stra = parameter.split("/");
		String kind = stra[0];
		String value = stra[1];
		
		if(kind.equals("i_num")) {
			buyhistoryVO = icsdao.searchshi_num(value);
		}else if(kind.equals("i_name")) {			
			buyhistoryVO = icsdao.searchshi_name(value);
		}else if(kind.equals("b_name")) {
			buyhistoryVO = icsdao.searchshb_name(value);
		}else if(kind.equals("date")) {
			String from = value.split("~")[0];
			String to = value.split("~")[1];
			
			dateVO.setFrom(from);
			dateVO.setTo(to);

			buyhistoryVO = icsdao.searchshdate(dateVO);
		}else if(kind.equals("who")) {
			buyhistoryVO = icsdao.searchshwho(value);
		}
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.INT);
		ds.addColumn("�Ѱ���", DataTypes.INT);
		ds.addColumn("�Ǹ���", DataTypes.STRING, (short)50);
		ds.addColumn("�����", DataTypes.STRING, (short)50);
		
		for(int i=0; i<buyhistoryVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", buyhistoryVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", buyhistoryVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", buyhistoryVO.get(i).getI_num());
			ds.set(row, "��ǰ��", buyhistoryVO.get(i).getI_name());
			ds.set(row, "����", buyhistoryVO.get(i).getCount());
			ds.set(row, "�Ѱ���", buyhistoryVO.get(i).getPrice() * buyhistoryVO.get(i).getCount());
			ds.set(row, "�Ǹ���", buyhistoryVO.get(i).getB_date());
			ds.set(row, "�����", buyhistoryVO.get(i).getWho());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public int subwarehouse(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return icsdao.subwarehouse(icsVO);
	}

	@Override
	public int addcollect(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return icsdao.addcollect(icsVO);
	}

	@Override
	public int addsellhistory(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return icsdao.addsellhistory(icsVO);
	}

	@Override
	public PlatformData loadunstorepopup() {
		// TODO Auto-generated method stub
		
		uitemVO = icsdao.loadunstorepopup();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.INT);
		ds.addColumn("�����", DataTypes.INT);
		ds.addColumn("EA", DataTypes.STRING, (short)50);
		
		for(int i=0; i<uitemVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "��ǰ��ȣ", uitemVO.get(i).getI_num());
			ds.set(row, "��ǰ��", uitemVO.get(i).getI_name());
			ds.set(row, "����" , uitemVO.get(i).getPrice());
			ds.set(row, "�����", uitemVO.get(i).getCount());
			ds.set(row, "EA", uitemVO.get(i).getEa());
		}
		
		pd.addDataSet(ds);
		
		return pd;				
	}

	@Override
	public PlatformData loadsellhistory() {
		// TODO Auto-generated method stub
		buyhistoryVO = icsdao.loadsellhistory();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("����", DataTypes.INT);
		ds.addColumn("�Ѱ���", DataTypes.INT);
		ds.addColumn("�Ǹ���", DataTypes.STRING, (short)50);
		ds.addColumn("�����", DataTypes.STRING, (short)50);
		
		for(int i=0; i<buyhistoryVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", buyhistoryVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", buyhistoryVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", buyhistoryVO.get(i).getI_num());
			ds.set(row, "��ǰ��", buyhistoryVO.get(i).getI_name());
			ds.set(row, "����", buyhistoryVO.get(i).getCount());
			ds.set(row, "�Ѱ���", buyhistoryVO.get(i).getPrice() * buyhistoryVO.get(i).getCount());
			ds.set(row, "�Ǹ���", buyhistoryVO.get(i).getB_date());
			ds.set(row, "�����", buyhistoryVO.get(i).getWho());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public PlatformData loadpayment() {
		// TODO Auto-generated method stub
		paymentVO = icsdao.loadpayment();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);		
		ds.addColumn("�����޾�", DataTypes.INT);
		ds.addColumn("�����ѱݾ�", DataTypes.INT);
		ds.addColumn("�����ݾ�", DataTypes.INT);
		ds.addColumn("���ޱ���", DataTypes.STRING, (short)50);
		
		for(int i=0; i<paymentVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", paymentVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", paymentVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", paymentVO.get(i).getI_num());
			ds.set(row, "��ǰ��", paymentVO.get(i).getI_name());
			ds.set(row, "�����޾�", paymentVO.get(i).getP_allmoney());
			ds.set(row, "�����ѱݾ�", paymentVO.get(i).getP_money());
			ds.set(row, "�����ݾ�", paymentVO.get(i).getP_allmoney() - paymentVO.get(i).getP_money());
			ds.set(row, "���ޱ���", paymentVO.get(i).getD_date());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}
	
	@Override
	public PlatformData loadcollect() {
		// TODO Auto-generated method stub
		paymentVO = icsdao.loadcollect();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);		
		ds.addColumn("�Ѽ��ݾ�", DataTypes.INT);
		ds.addColumn("�����ѱݾ�", DataTypes.INT);
		ds.addColumn("�����ݾ�", DataTypes.INT);
		ds.addColumn("���ݱ���", DataTypes.STRING, (short)50);
		
		for(int i=0; i<paymentVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", paymentVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", paymentVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", paymentVO.get(i).getI_num());
			ds.set(row, "��ǰ��", paymentVO.get(i).getI_name());
			ds.set(row, "�Ѽ��ݾ�", paymentVO.get(i).getP_allmoney());
			ds.set(row, "�����ѱݾ�", paymentVO.get(i).getP_money());
			ds.set(row, "�����ݾ�", paymentVO.get(i).getP_allmoney() - paymentVO.get(i).getP_money());
			ds.set(row, "���ݱ���", paymentVO.get(i).getD_date());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}

	@Override
	public int updatepayment(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return icsdao.updatepayment(paymentVO);
	}

	@Override
	public int addpayhistory(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return icsdao.addpayhistory(paymentVO);
	}
		
	@Override
	public int updatecollect(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return icsdao.updatecollect(paymentVO);
	}

	@Override
	public int addcolhistory(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return icsdao.addcolhistory(paymentVO);
	}
	
	@Override
	public PlatformData loadpayhistory() {
		// TODO Auto-generated method stub
		payhistoryVO = icsdao.loadpayhistory();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);		
		ds.addColumn("���޾�", DataTypes.INT);
		ds.addColumn("���޳�¥", DataTypes.STRING, (short)50);	
		ds.addColumn("�����", DataTypes.STRING, (short)50);	
		
		for(int i=0; i<payhistoryVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", payhistoryVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", payhistoryVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", payhistoryVO.get(i).getI_num());
			ds.set(row, "��ǰ��", payhistoryVO.get(i).getI_name());
			ds.set(row, "���޾�", payhistoryVO.get(i).getMoney());
			ds.set(row, "���޳�¥", payhistoryVO.get(i).getP_date());
			ds.set(row, "�����", payhistoryVO.get(i).getWho());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}
	
	@Override
	public PlatformData loadcolhistory() {
		// TODO Auto-generated method stub
		payhistoryVO = icsdao.loadcolhistory();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("No", DataTypes.INT);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);		
		ds.addColumn("���ݾ�", DataTypes.INT);
		ds.addColumn("���ݳ�¥", DataTypes.STRING, (short)50);	
		ds.addColumn("�����", DataTypes.STRING, (short)50);	
		
		for(int i=0; i<payhistoryVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "No", payhistoryVO.get(i).getId());
			ds.set(row, "�ŷ�ó��", payhistoryVO.get(i).getB_name());
			ds.set(row, "��ǰ��ȣ", payhistoryVO.get(i).getI_num());
			ds.set(row, "��ǰ��", payhistoryVO.get(i).getI_name());
			ds.set(row, "���ݾ�", payhistoryVO.get(i).getMoney());
			ds.set(row, "���ݳ�¥", payhistoryVO.get(i).getP_date());
			ds.set(row, "�����", payhistoryVO.get(i).getWho());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}
	
	@Override
	public int storecountfinish(IcsVO icsVO) {
		
		int count = icsdao.existcountfinish(icsVO);
		
		if(count>=1) {
		//update
			return icsdao.updatestorecountfinish(icsVO);			
		}else {
		//insert
			return icsdao.addstorecountfinish(icsVO);			
		}
	
	}
	
	@Override
	public int unstorecountfinish(IcsVO icsVO) {
		
		int count = icsdao.existcountfinish(icsVO);
		
		if(count>=1) {
		//update
			return icsdao.updateunstorecountfinish(icsVO);			
		}else {
		//insert
			return icsdao.addunstorecountfinish(icsVO);			
		}
	
	}
	
	@Override
	public int storemoneyfinish(IcsVO icsVO) {
		
		int count = icsdao.existmoneyfinish(icsVO);
		
		if(count>=1) {
		//update
			return icsdao.updatestoremoneyfinish(icsVO);			
		}else {
		//insert
			return icsdao.addstoremoneyfinish(icsVO);			
		}
	
	}
		
	@Override
	public int unstoremoneyfinish(IcsVO icsVO) {
		
		int count = icsdao.existmoneyfinish(icsVO);
		
		if(count>=1) {
		//update
			return icsdao.updateunstoremoneyfinish(icsVO);			
		}else {
		//insert
			return icsdao.addunstoremoneyfinish(icsVO);			
		}
	
	}

	@Override
	public PlatformData loadcountfinish() {
		// TODO Auto-generated method stub
		countfinishVO = icsdao.loadcountfinish();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("��", DataTypes.STRING, (short)50);
		ds.addColumn("��", DataTypes.STRING, (short)50);	
		ds.addColumn("��ǰ��ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("��ǰ��", DataTypes.STRING, (short)50);
		ds.addColumn("�̿����", DataTypes.INT);
		ds.addColumn("�ݿ����", DataTypes.INT);
		ds.addColumn("�ݿ��԰�", DataTypes.INT);
		ds.addColumn("�����", DataTypes.INT);
		ds.addColumn("��������", DataTypes.STRING, (short)50);	
		
		for(int i=0; i<countfinishVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "��", countfinishVO.get(i).getFyear());
			ds.set(row, "��", countfinishVO.get(i).getFmonth());
			ds.set(row, "��ǰ��ȣ", countfinishVO.get(i).getI_num());
			ds.set(row, "��ǰ��", countfinishVO.get(i).getI_name());
			ds.set(row, "�̿����", countfinishVO.get(i).getPre_count());
			ds.set(row, "�ݿ����", countfinishVO.get(i).getU_count());
			ds.set(row, "�ݿ��԰�", countfinishVO.get(i).getS_count());
			ds.set(row, "�����", countfinishVO.get(i).getN_count());
			ds.set(row, "��������", countfinishVO.get(i).getFlag());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}
	
	@Override
	public PlatformData loadmoneyfinish() {
		// TODO Auto-generated method stub
		moneyfinishVO = icsdao.loadmoneyfinish();
		
		PlatformData pd = new PlatformData();
		DataSet ds = new DataSet("ds_out");
		ds.addColumn("��", DataTypes.STRING, (short)50);
		ds.addColumn("��", DataTypes.STRING, (short)50);	
		ds.addColumn("����ڹ�ȣ", DataTypes.STRING, (short)50);
		ds.addColumn("�ŷ�ó��", DataTypes.STRING, (short)50);
		ds.addColumn("�ݿ����ž�", DataTypes.INT);
		ds.addColumn("�ݿ����޾�", DataTypes.INT);
		ds.addColumn("�ݿ��Ǹž�", DataTypes.INT);
		ds.addColumn("�ݿ����ݾ�", DataTypes.INT);
		ds.addColumn("��������", DataTypes.STRING, (short)50);	
		
		for(int i=0; i<moneyfinishVO.size(); i++) {
			int row = ds.newRow();
			ds.set(row, "��", moneyfinishVO.get(i).getFyear());
			ds.set(row, "��", moneyfinishVO.get(i).getFmonth());
			ds.set(row, "����ڹ�ȣ", moneyfinishVO.get(i).getB_num());
			ds.set(row, "�ŷ�ó��", moneyfinishVO.get(i).getB_name());
			ds.set(row, "�ݿ����ž�", moneyfinishVO.get(i).getB_money());
			ds.set(row, "�ݿ����޾�", moneyfinishVO.get(i).getP_money());
			ds.set(row, "�ݿ��Ǹž�", moneyfinishVO.get(i).getS_money());
			ds.set(row, "�ݿ����ݾ�", moneyfinishVO.get(i).getC_money());
			ds.set(row, "��������", moneyfinishVO.get(i).getFlag());
		}
		
		pd.addDataSet(ds);
		
		return pd;
	}
	
	@Override
	public int pmoneyfinish(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		int count = icsdao.existmoneyfinish1(paymentVO);
		
		if(count>=1) {
			return icsdao.updatepmoneyfinish(paymentVO);
		}else {			
			return icsdao.addpmoneyfinish(paymentVO);
		}		
	}
	
	@Override
	public int cmoneyfinish(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		int count = icsdao.existmoneyfinish2(paymentVO);
		
		if(count>=1) {
			return icsdao.updatecmoneyfinish(paymentVO);
		}else {
			return icsdao.addcmoneyfinish(paymentVO);
		}		
	}
	
	@Override
	public int finish(DateVO dateVO) {				
		return icsdao.finish(dateVO);
	}
	
	@Override
	public int unfinish(DateVO dateVO) {				
		return icsdao.unfinish(dateVO);
	}
	
	@Override
	public int revisebuyhistory(BuyhistoryVO buyhistoryVO) {
		
		int p_money = icsdao.checkbuyhistory(buyhistoryVO);
		
		if(p_money > 0) {
			int a = 1 / 0;
		}else {
			//�����������
			icsdao.revisewarehouse(buyhistoryVO);//����
			icsdao.revisepayment(buyhistoryVO);//����
			icsdao.revisestorecountfinish(buyhistoryVO);//����
			icsdao.revisestoreprecountfinish(buyhistoryVO);//����
			icsdao.revisestoremoneyfinish(buyhistoryVO);//����
			icsdao.revisebuyhistory(buyhistoryVO);//����
		}
		
		return 0;
	}
	
	@Override
	public int canclebuyhistory(BuyhistoryVO buyhistoryVO) {
		
		//�����������
		icsdao.canclewarehouse(buyhistoryVO);//����
		icsdao.canclepayment(buyhistoryVO);//����
		icsdao.canclestorecountfinish(buyhistoryVO);//����
		icsdao.canclestoreprecountfinish(buyhistoryVO);//����
		icsdao.canclestoremoneyfinish(buyhistoryVO);//����
		
		
		payhistoryVO = icsdao.checkpayhistory(buyhistoryVO);
		
		for(int i=0; i<payhistoryVO.size(); i++) {
			icsdao.canclestorep_moneyfinish(payhistoryVO.get(i));			
		}		
		
		icsdao.canclebuyhistory(buyhistoryVO);//����
		icsdao.canclepayhistory(buyhistoryVO);//����
				
		return 0;
	}
	
	@Override
	public int revisesellhistory(BuyhistoryVO buyhistoryVO) {
		
		int c_money = icsdao.checksellhistory(buyhistoryVO);
		
		if(c_money > 0) {
			int a = 1 / 0;
		}else {
			//�����������
			icsdao.revisewarehouse2(buyhistoryVO);//����
			icsdao.revisecollect(buyhistoryVO);//����
			icsdao.reviseunstorecountfinish(buyhistoryVO);//����
			icsdao.reviseunstoreprecountfinish(buyhistoryVO);//����
			icsdao.reviseunstoremoneyfinish(buyhistoryVO);//����
			icsdao.revisesellhistory(buyhistoryVO);//����
		}
		
		return 0;
	}
	
	@Override
	public int canclesellhistory(BuyhistoryVO buyhistoryVO) {
		
		//�����������
		icsdao.canclewarehouse2(buyhistoryVO);//����
		icsdao.canclecollect(buyhistoryVO);//����
		icsdao.cancleunstorecountfinish(buyhistoryVO);//����
		icsdao.cancleunstoreprecountfinish(buyhistoryVO);
		icsdao.cancleunstoremoneyfinish(buyhistoryVO);//����
		
		payhistoryVO = icsdao.checkcolhistory(buyhistoryVO);
		
		for(int i=0; i<payhistoryVO.size(); i++) {
			icsdao.cancleunstorec_moneyfinish(payhistoryVO.get(i));			
		}
		
		icsdao.canclesellhistory(buyhistoryVO);//����
		icsdao.canclecolhistory(buyhistoryVO);//����
				
		return 0;
	}

	@Override
	public int checkfinish(DateVO dateVO) {
		// TODO Auto-generated method stub
		
		String state = icsdao.checkfinish(dateVO);
		
		if(state.equals("�Ϸ�")) {
			int a = 1 / 0;
		}
		
		return 0;
	}

	@Override
	public int checksellwarehouse(HashMap<String, String> map) {
		// TODO Auto-generated method stub
		int warehousecount = icsdao.checksellwarehouse(map);
		
		if(warehousecount + Integer.parseInt(map.get("nowcount")) < Integer.parseInt(map.get("revisecount"))) {
			int a = 1/0;
		}
		
		return 0;
	}
	
	@Override
	public int canclepayhistory(PayhistoryVO payhistoryVO) {
		
		//�����������
		icsdao.canclephpayment(payhistoryVO);//����
		icsdao.canclephmoneyfinish(payhistoryVO);//����
		icsdao.canclephpayhistory(payhistoryVO);//����
				
		return 0;
	}
	
	@Override
	public int canclecolhistory(PayhistoryVO payhistoryVO) {
		
		//�����������
		icsdao.canclechcollect(payhistoryVO);//����
		icsdao.canclechmoneyfinish(payhistoryVO);//����
		icsdao.canclechcolhistory(payhistoryVO);//����
				
		return 0;
	}
		
}
