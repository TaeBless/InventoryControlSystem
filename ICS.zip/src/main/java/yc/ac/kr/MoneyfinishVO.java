package yc.ac.kr;

public class MoneyfinishVO {
	
	private String fyear;
	private String fmonth;
	private String b_num;
	private String b_name;
	private int b_money;
	private int p_money;
	private int s_money;
	private int c_money;
	private String flag;
	
	public String getFyear() {
		return fyear;
	}
	public void setFyear(String fyear) {
		this.fyear = fyear;
	}
	public int getP_money() {
		return p_money;
	}
	public void setP_money(int p_money) {
		this.p_money = p_money;
	}
	public int getC_money() {
		return c_money;
	}
	public void setC_money(int c_money) {
		this.c_money = c_money;
	}
	
	public int getB_money() {
		return b_money;
	}
	
	public void setB_money(int b_money) {
		this.b_money = b_money;
	}
	
	public int getS_money() {
		return s_money;
	}
	
	public void setS_money(int s_money) {
		this.s_money = s_money;
	}
	
	public String getFmonth() {
		return fmonth;
	}
	public void setFmonth(String fmonth) {
		this.fmonth = fmonth;
	}
	public String getB_num() {
		return b_num;
	}
	public void setB_num(String b_num) {
		this.b_num = b_num;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	
	
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
}
