package yc.ac.kr;

public class PaymentVO {
	
	private int id;
	private String b_name;
	private String i_num;
	private String i_name;
	private int p_allmoney;
	private int p_money;
	private String d_date;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getI_num() {
		return i_num;
	}
	public void setI_num(String i_num) {
		this.i_num = i_num;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public int getP_allmoney() {
		return p_allmoney;
	}
	public void setP_allmoney(int p_allmoney) {
		this.p_allmoney = p_allmoney;
	}
	public int getP_money() {
		return p_money;
	}
	public void setP_money(int p_money) {
		this.p_money = p_money;
	}
	public String getD_date() {
		return d_date;
	}
	public void setD_date(String d_date) {
		this.d_date = d_date;
	}	

}
