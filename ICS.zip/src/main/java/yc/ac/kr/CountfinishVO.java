package yc.ac.kr;

public class CountfinishVO {
	
	private String fyear;
	private String fmonth;
	private String i_num;
	private String i_name;
	private int pre_count;
	private int u_count;
	private int s_count;
	private int n_count;
	private String flag;
	
	public String getFyear() {
		return fyear;
	}
	public void setFyear(String fyear) {
		this.fyear = fyear;
	}
	public String getFmonth() {
		return fmonth;
	}
	public void setFmonth(String fmonth) {
		this.fmonth = fmonth;
	}
	public String getI_num() {
		return i_num;
	}
	public void setI_num(String i_num) {
		this.i_num = i_num;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public int getPre_count() {
		return pre_count;
	}
	public void setPre_count(int pre_count) {
		this.pre_count = pre_count;
	}
	public int getU_count() {
		return u_count;
	}
	public void setU_count(int u_count) {
		this.u_count = u_count;
	}
	public int getS_count() {
		return s_count;
	}
	public void setS_count(int s_count) {
		this.s_count = s_count;
	}
	public int getN_count() {
		return n_count;
	}
	public void setN_count(int n_count) {
		this.n_count = n_count;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
}
