package yc.ac.kr;

import java.text.ParseException;
import java.util.HashMap;

import com.nexacro17.xapi.data.PlatformData;

public interface ICSServiceImp {
	
	public PlatformData loaditem();
	public PlatformData loadbusiness();
	public PlatformData loadunstorepopup();
	public int addbusiness(BusinessVO businessVO);
	public PlatformData searchbusiness(String parameter);
	public int deletebusiness(String parameter);
	public int additem(ItemVO itemVO);
	public int deleteitem(String parameter);
	public PlatformData searchitem(String parameter);
	public int addwarehouse(IcsVO icsVO);
	public int addpayment(IcsVO icsVO);
	public int addbuyhistory(IcsVO icsVO);
	public int storecountfinish(IcsVO icsVO);
	public int storemoneyfinish(IcsVO icsVO);
	public int unstorecountfinish(IcsVO icsVO);
	public int unstoremoneyfinish(IcsVO icsVO);
	public PlatformData loadwarehouse();
	public PlatformData searchwarehouse(String parameter) throws ParseException;
	public PlatformData loadbuyhistory();
	public PlatformData loadpayment();
	public PlatformData loadcollect();
	public PlatformData loadsellhistory();
	public PlatformData searchbuyhistory(String parameter);
	public PlatformData searchsellhistory(String parameter);
	public int subwarehouse(IcsVO icsVO);
	public int addcollect(IcsVO icsVO);
	public int addsellhistory(IcsVO icsVO);
	public int updatepayment(PaymentVO paymentVO);
	public int addpayhistory(PaymentVO paymentVO);
	public PlatformData loadpayhistory();
	public PlatformData loadcolhistory();
	public int updatecollect(PaymentVO paymentVO);
	public int addcolhistory(PaymentVO paymentVO);
	public PlatformData loadcountfinish();
	public PlatformData loadmoneyfinish();
	public int pmoneyfinish(PaymentVO paymentVO);
	public int cmoneyfinish(PaymentVO paymentVO);
	public int finish(DateVO dateVO);
	public int unfinish(DateVO dateVO);
	public int revisebuyhistory(BuyhistoryVO buyhistoryVO);
	public int canclebuyhistory(BuyhistoryVO buyhistoryVO);
	public int revisesellhistory(BuyhistoryVO buyhistoryVO);
	public int canclesellhistory(BuyhistoryVO buyhistoryVO);
	public int checkfinish(DateVO dateVO);
	public int checksellwarehouse(HashMap<String, String> map);
	public int canclepayhistory(PayhistoryVO payhistoryVO);
	public int canclecolhistory(PayhistoryVO payhistoryVO);
}
