package yc.ac.kr;

public class WarehouseVO {
	
	private int id;
	private String i_num;
	private String i_name;
	private int count;
	private String l_date;
	private String ea;
	
	public int getId() {
		return id;
	}
	public String getEa() {
		return ea;
	}
	public void setEa(String ea) {
		this.ea = ea;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getI_num() {
		return i_num;
	}
	public void setI_num(String i_num) {
		this.i_num = i_num;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getL_date() {
		return l_date;
	}
	public void setL_date(String l_date) {
		this.l_date = l_date;
	}
	
	

}
