package yc.ac.kr;

import java.util.HashMap;
import java.util.List;

public interface ICSDaoImp {
	
	public List<BusinessVO> loadbusiness();
	public int addbusiness(BusinessVO businessVO);
	public List<BusinessVO> searchb_num(String parameter);
	public List<BusinessVO> searchb_name(String parameter);
	public List<BusinessVO> searchb_loc(String parameter);
	public int deletebusiness(String parameter);
	public List<ItemVO> loaditem();
	public int additem(ItemVO itemVO);
	public int deleteitem(String parameter);
	public List<ItemVO> searchib_num(String parameter);
	public List<ItemVO> searchib_name(String parameter);
	public List<ItemVO> searchi_num(String parameter);
	public List<ItemVO> searchi_name(String parameter);
	public int addwarehouse(IcsVO icsVO);
	public int addpayment(IcsVO icsVO);
	public int addbuyhistory(IcsVO icsVO);
	public int subwarehouse(IcsVO icsVO);
	public int addcollect(IcsVO icsVO);
	public int addsellhistory(IcsVO icsVO);
	public List<WarehouseVO> loadwarehouse();
	public List<WarehouseVO> searchwi_num(String parameter);
	public List<WarehouseVO> searchwi_name(String parameter);
	public List<WarehouseVO> searchwdate(DateVO dateVO);
	public List<BuyhistoryVO> loadbuyhistory();
	public List<BuyhistoryVO> loadsellhistory();
	public List<PaymentVO> loadpayment();
	public List<PaymentVO> loadcollect();
	public List<BuyhistoryVO> searchbhi_num(String parameter);
	public List<BuyhistoryVO> searchbhb_name(String parameter);
	public List<BuyhistoryVO> searchbhi_name(String parameter);
	public List<BuyhistoryVO> searchbhdate(DateVO dateVO);
	public List<BuyhistoryVO> searchbhwho(String parameter);
	public List<BuyhistoryVO> searchshi_num(String parameter);
	public List<BuyhistoryVO> searchshb_name(String parameter);
	public List<BuyhistoryVO> searchshi_name(String parameter);
	public List<BuyhistoryVO> searchshdate(DateVO dateVO);
	public List<BuyhistoryVO> searchshwho(String parameter);
	public List<UitemVO> loadunstorepopup();
	public int updatepayment(PaymentVO paymentVO);
	public int addpayhistory(PaymentVO paymentVO);
	public int updatecollect(PaymentVO paymentVO);
	public int addcolhistory(PaymentVO paymentVO);
	public List<PayhistoryVO> loadpayhistory();
	public List<PayhistoryVO> loadcolhistory();
	public int updatestorecountfinish(IcsVO icsVO);
	public int addstorecountfinish(IcsVO icsVO);
	public int updateunstorecountfinish(IcsVO icsVO);
	public int addunstorecountfinish(IcsVO icsVO);
	public int existcountfinish(IcsVO icsVO);
	public int existmoneyfinish(IcsVO icsVO);
	public int existmoneyfinish1(PaymentVO paymentVO);
	public int existmoneyfinish2(PaymentVO paymentVO);
	public int updatestoremoneyfinish(IcsVO icsVO);
	public int addstoremoneyfinish(IcsVO icsVO);
	public int updateunstoremoneyfinish(IcsVO icsVO);
	public int addunstoremoneyfinish(IcsVO icsVO);
	public List<CountfinishVO> loadcountfinish();
	public List<MoneyfinishVO> loadmoneyfinish();
	public int existwarehouse(IcsVO icsVO);
	public int updatewarehouse(IcsVO icsVO);
	public int updatepmoneyfinish(PaymentVO paymentVO);
	public int updatecmoneyfinish(PaymentVO paymentVO);
	public int addpmoneyfinish(PaymentVO paymentVO);
	public int addcmoneyfinish(PaymentVO paymentVO);
	public int finish(DateVO dateVO);
	public int unfinish(DateVO dateVO);
	public int checkbuyhistory(BuyhistoryVO buyhistoryVO);
	public int checksellhistory(BuyhistoryVO buyhistoryVO);
	public int revisebuyhistory(BuyhistoryVO buyhistoryVO);
	public int revisepayment(BuyhistoryVO buyhistoryVO);
	public int revisewarehouse(BuyhistoryVO buyhistoryVO);
	public int canclewarehouse(BuyhistoryVO buyhistoryVO);//����
	public int canclepayment(BuyhistoryVO buyhistoryVO);//����
	public int canclebuyhistory(BuyhistoryVO buyhistoryVO);//����
	public int canclepayhistory(BuyhistoryVO buyhistoryVO);//����
	public int revisesellhistory(BuyhistoryVO buyhistoryVO);
	public int revisecollect(BuyhistoryVO buyhistoryVO);
	public int revisewarehouse2(BuyhistoryVO buyhistoryVO);
	public int canclewarehouse2(BuyhistoryVO buyhistoryVO);//����
	public int canclecollect(BuyhistoryVO buyhistoryVO);//����
	public int canclesellhistory(BuyhistoryVO buyhistoryVO);//����
	public int canclecolhistory(BuyhistoryVO buyhistoryVO);//����
	public String checkfinish(DateVO dateVO);
	public int checksellwarehouse(HashMap<String,String> map);
	public int revisestorecountfinish(BuyhistoryVO buyhistoryVO);
	public int revisestoreprecountfinish(BuyhistoryVO buyhistoryVO);
	public int revisestoremoneyfinish(BuyhistoryVO buyhistoryVO);
	public int canclestorecountfinish(BuyhistoryVO buyhistoryVO);//����
	public int canclestoreprecountfinish(BuyhistoryVO buyhistoryVO);
	public int canclestoremoneyfinish(BuyhistoryVO buyhistoryVO);//����
	public int reviseunstorecountfinish(BuyhistoryVO buyhistoryVO);
	public int reviseunstoreprecountfinish(BuyhistoryVO buyhistoryVO);
	public int reviseunstoremoneyfinish(BuyhistoryVO buyhistoryVO);
	public int cancleunstorecountfinish(BuyhistoryVO buyhistoryVO);//����
	public int cancleunstoreprecountfinish(BuyhistoryVO buyhistoryVO);
	public int cancleunstoremoneyfinish(BuyhistoryVO buyhistoryVO);//����
	public List<PayhistoryVO> checkpayhistory(BuyhistoryVO buyhistoryVO);
	public List<PayhistoryVO> checkcolhistory(BuyhistoryVO buyhistoryVO);
	public int canclestorep_moneyfinish(PayhistoryVO payhistoryVO);
	public int cancleunstorec_moneyfinish(PayhistoryVO payhistoryVO);
	public int canclephpayment(PayhistoryVO payhistoryVO);
	public int canclephmoneyfinish(PayhistoryVO payhistoryVO);
	public int canclephpayhistory(PayhistoryVO payhistoryVO);
	public int canclechcollect(PayhistoryVO payhistoryVO);
	public int canclechmoneyfinish(PayhistoryVO payhistoryVO);
	public int canclechcolhistory(PayhistoryVO payhistoryVO);
}
