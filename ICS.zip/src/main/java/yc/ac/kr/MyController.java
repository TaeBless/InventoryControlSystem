package yc.ac.kr;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro17.xapi.data.PlatformData;
import com.nexacro17.xapi.data.Variable;
import com.nexacro17.xapi.tx.HttpPlatformRequest;
import com.nexacro17.xapi.tx.PlatformException;

/**
 * Handles requests for the application home page.
 */
@Controller
public class MyController {
	
	@Inject
	private ICSService icsservice;
	
	@RequestMapping(value = "/loaditem")
	public String loaditem(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loaditem();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/additem")
	public String additem(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		ItemVO itemVO = new ItemVO();
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		itemVO.setI_num(reqpd.getVariable("i_num").getString());
		itemVO.setI_name(reqpd.getVariable("i_name").getString());
		itemVO.setB_num(reqpd.getVariable("b_num").getString());
		itemVO.setB_name(reqpd.getVariable("b_name").getString());
		itemVO.setPrice(reqpd.getVariable("price").getInt());
		itemVO.setEa(reqpd.getVariable("ea").getString());		
		
		icsservice.additem(itemVO);
		
		return null;
	}
	
	@RequestMapping(value = "/loadbusiness")
	public String loadbusiness(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadbusiness();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadunstorepopup")
	public String loadunstorepopup(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadunstorepopup();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadpayment")
	public String loadpayment(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadpayment();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadcollect")
	public String loadcollect(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadcollect();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/addbusiness")
	public String addbusiness(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		BusinessVO businessVO = new BusinessVO();
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		businessVO.setB_num(reqpd.getVariable("b_num").getString());
		businessVO.setB_name(reqpd.getVariable("b_name").getString());
		businessVO.setB_loc(reqpd.getVariable("b_loc").getString());
		
		icsservice.addbusiness(businessVO);
		
		return null;
	}
		
	@RequestMapping(value = "/searchbusiness")
	public String searchbusiness(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		String parameter = reqpd.getVariable(0).getString();
		
		PlatformData pd = icsservice.searchbusiness(parameter);
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/searchitem")
	public String searchitem(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		String parameter = reqpd.getVariable(0).getString();
		
		PlatformData pd = icsservice.searchitem(parameter);
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/deletebusiness")
	public String deletebusiness(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		String b_num = reqpd.getVariable(0).getString();
		
		icsservice.deletebusiness(b_num);
		
		return null;
	}
	
	@RequestMapping(value = "/deleteitem")
	public String deleteitem(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		String i_num = reqpd.getVariable(0).getString();
		
		icsservice.deleteitem(i_num);
		
		return null;
	}
	
	@RequestMapping(value = "/payment")
	public String payment(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		PaymentVO paymentVO = new PaymentVO();
		paymentVO.setId(reqpd.getVariable("id").getInt());
		paymentVO.setP_money(reqpd.getVariable("money").getInt());
		
		icsservice.updatepayment(paymentVO);
		icsservice.addpayhistory(paymentVO);
		icsservice.pmoneyfinish(paymentVO);
		
		return null;
	}
	
	@RequestMapping(value = "/collect")
	public String collect(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		PaymentVO paymentVO = new PaymentVO();
		paymentVO.setId(reqpd.getVariable("id").getInt());
		paymentVO.setP_money(reqpd.getVariable("money").getInt());
		
		icsservice.updatecollect(paymentVO);
		icsservice.addcolhistory(paymentVO);
		icsservice.cmoneyfinish(paymentVO);
		
		return null;
	}
	
	@RequestMapping(value = "/loadpayhistory")
	public String loadpayhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadpayhistory();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadcolhistory")
	public String loadcolhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadcolhistory();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/storing")
	public String storing(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		IcsVO icsVO = new IcsVO();
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		icsVO.setI_num(reqpd.getVariable("i_num").getString());
		icsVO.setI_name(reqpd.getVariable("i_name").getString());
		icsVO.setB_num(reqpd.getVariable("b_num").getString());
		icsVO.setB_name(reqpd.getVariable("b_name").getString());
		icsVO.setPrice(reqpd.getVariable("price").getInt());
		icsVO.setEa(reqpd.getVariable("ea").getString());
		icsVO.setSale(reqpd.getVariable("sale").getInt());
		icsVO.setCount(reqpd.getVariable("count").getInt());
		icsVO.setDdate(reqpd.getVariable("ddate").getString());
		
		icsservice.storecountfinish(icsVO);
		icsservice.storemoneyfinish(icsVO);
		icsservice.addwarehouse(icsVO);
		icsservice.addpayment(icsVO);
		icsservice.addbuyhistory(icsVO);
		
		return null;
	}
	
	@RequestMapping(value = "/unstoring")
	public String unstoring(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		IcsVO icsVO = new IcsVO();
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		icsVO.setI_num(reqpd.getVariable("i_num").getString());
		icsVO.setI_name(reqpd.getVariable("i_name").getString());
		icsVO.setB_num(reqpd.getVariable("b_num").getString());
		icsVO.setB_name(reqpd.getVariable("b_name").getString());
		icsVO.setPrice(reqpd.getVariable("rprice").getInt());
		icsVO.setCount(reqpd.getVariable("count").getInt());
		icsVO.setDdate(reqpd.getVariable("ddate").getString());
		
		
		icsservice.unstorecountfinish(icsVO);
		icsservice.unstoremoneyfinish(icsVO);
		icsservice.subwarehouse(icsVO);
		icsservice.addcollect(icsVO);
		icsservice.addsellhistory(icsVO);
		
		return null;
	}
	
	@RequestMapping(value = "/loadwarehouse")
	public String loadwarehouse(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadwarehouse();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/searchwarehouse")
	public String searchwarehouse(Locale locale, Model model, HttpServletRequest request) throws PlatformException, ParseException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		
		PlatformData reqpd = req.getData();
		
		String str = reqpd.getVariable(0).getString();
		
		PlatformData pd = icsservice.searchwarehouse(str);
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/searchbuyhistory")
	public String searchbuyhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException, ParseException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		
		PlatformData reqpd = req.getData();
		
		String str = reqpd.getVariable(0).getString();
		
		PlatformData pd = icsservice.searchbuyhistory(str);
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/searchsellhistory")
	public String searchsellhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException, ParseException {
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		
		PlatformData reqpd = req.getData();
		
		String str = reqpd.getVariable(0).getString();
		
		PlatformData pd = icsservice.searchsellhistory(str);
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadbuyhistory")
	public String loadbuyhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadbuyhistory();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadsellhistory")
	public String loadsellhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadsellhistory();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadcountfinish")
	public String loadcountfinish(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadcountfinish();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/loadmoneyfinish")
	public String loadmoneyfinish(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		PlatformData pd = icsservice.loadmoneyfinish();
		model.addAttribute("pdata", pd);
		
		return "home";
	}
	
	@RequestMapping(value = "/finish")
	public String finish(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		String date = reqpd.getVariable(0).getString();
				
		DateVO dateVO = new DateVO();
		
		dateVO.setFrom(date.split("/")[0]);
		dateVO.setTo(date.split("/")[1]);
		
		icsservice.finish(dateVO);
		
		return null;
	}
	
	@RequestMapping(value = "/unfinish")
	public String unfinish(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		String date = reqpd.getVariable(0).getString();
				
		DateVO dateVO = new DateVO();
		
		dateVO.setFrom(date.split("/")[0]);
		dateVO.setTo(date.split("/")[1]);
		
		icsservice.unfinish(dateVO);
		
		return null;
	}
	
	@RequestMapping(value = "/revisebuyhistory")
	public String revisebuyhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		BuyhistoryVO buyhistoryVO = new BuyhistoryVO();
		
		buyhistoryVO.setId(reqpd.getVariable("no").getInt());
		buyhistoryVO.setI_num(reqpd.getVariable("i_num").getString());
		buyhistoryVO.setCount(reqpd.getVariable("count").getInt());
		buyhistoryVO.setB_date(reqpd.getVariable("buy_year").getString() + "/" + reqpd.getVariable("buy_month").getString());
		
		icsservice.revisebuyhistory(buyhistoryVO);
		
		return "error";
	}
	
	@RequestMapping(value = "/canclebuyhistory")
	public String canclebuyhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		BuyhistoryVO buyhistoryVO = new BuyhistoryVO();
		
		buyhistoryVO.setId(reqpd.getVariable("no").getInt());
		buyhistoryVO.setI_num(reqpd.getVariable("i_num").getString());
		buyhistoryVO.setCount(reqpd.getVariable("count").getInt());
		buyhistoryVO.setB_date(reqpd.getVariable("buy_year").getString() + "/" + reqpd.getVariable("buy_month").getString());
		
		icsservice.canclebuyhistory(buyhistoryVO);
		
		return "error";
	}
	
	@RequestMapping(value = "/revisesellhistory")
	public String revisesellhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
				
		BuyhistoryVO buyhistoryVO = new BuyhistoryVO();
		
		buyhistoryVO.setId(reqpd.getVariable("no").getInt());
		buyhistoryVO.setI_num(reqpd.getVariable("i_num").getString());
		buyhistoryVO.setCount(reqpd.getVariable("count").getInt());
		buyhistoryVO.setB_date(reqpd.getVariable("sell_year").getInt() + "/" + reqpd.getVariable("sell_month").getInt());
		
		
		icsservice.revisesellhistory(buyhistoryVO);
		
		return "error";
	}
	
	@RequestMapping(value = "/canclesellhistory")
	public String canclesellhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		BuyhistoryVO buyhistoryVO = new BuyhistoryVO();
		
		buyhistoryVO.setId(reqpd.getVariable("no").getInt());
		buyhistoryVO.setI_num(reqpd.getVariable("i_num").getString());
		buyhistoryVO.setCount(reqpd.getVariable("count").getInt());
		buyhistoryVO.setB_date(reqpd.getVariable("sell_year").getString() + "/" + reqpd.getVariable("sell_month").getString());
		
		icsservice.canclesellhistory(buyhistoryVO);
		
		return "error";
	}
	
	@RequestMapping(value = "/checkfinish")
	public String checkfinish(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
		
		System.out.println("checkfinish");
		
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		DateVO dateVO = new DateVO();
		
		dateVO.setFrom(reqpd.getVariable("buy_year").getString());
		dateVO.setTo(reqpd.getVariable("buy_month").getString());
		
		icsservice.checkfinish(dateVO);
		
		return "error";
	}
	
	@RequestMapping(value = "/checksellwarehouse")
	public String checksellwarehouse(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("i_num", reqpd.getVariable("i_num").getString());
		map.put("nowcount", reqpd.getVariable("nowcount").getString());
		map.put("revisecount", reqpd.getVariable("revisecount").getString());
		
		icsservice.checksellwarehouse(map);
		
		return "error";
	}
	
	@RequestMapping(value = "/canclepayhistory")
	public String canclepayhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		PayhistoryVO payhistoryVO = new PayhistoryVO();
		
		payhistoryVO.setId(reqpd.getVariable("no").getInt());
		payhistoryVO.setMoney(reqpd.getVariable("money").getInt());
		payhistoryVO.setP_date(reqpd.getVariable("pay_year").getString() + "/" + reqpd.getVariable("pay_month").getString());
		
		icsservice.canclepayhistory(payhistoryVO);
		
		return "error";
	}
	
	@RequestMapping(value = "/canclecolhistory")
	public String canclecolhistory(Locale locale, Model model, HttpServletRequest request) throws PlatformException {
				
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		req.receiveData();
		PlatformData reqpd = req.getData();
		
		PayhistoryVO payhistoryVO = new PayhistoryVO();
		
		payhistoryVO.setId(reqpd.getVariable("no").getInt());
		payhistoryVO.setMoney(reqpd.getVariable("money").getInt());
		payhistoryVO.setP_date(reqpd.getVariable("col_year").getString() + "/" + reqpd.getVariable("col_month").getString());
		
		icsservice.canclecolhistory(payhistoryVO);
		
		return "error";
	}
	
}
