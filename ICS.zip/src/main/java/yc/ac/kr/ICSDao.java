package yc.ac.kr;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;

@Component
public class ICSDao implements ICSDaoImp {
	
	@Inject
	private SqlSession session;
	
	private static String namespace = "yc.ac.kr.Mapper";

	@Override
	public List<BusinessVO> loadbusiness() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadbusiness");
	}

	@Override
	public int addbusiness(BusinessVO businessVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addbusiness", businessVO);
	}

	@Override
	public List<BusinessVO> searchb_num(String value) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchb_num", value);
	}

	@Override
	public List<BusinessVO> searchb_name(String value) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchb_name", value);
	}

	@Override
	public List<BusinessVO> searchb_loc(String value) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchb_loc", value);
	}

	@Override
	public int deletebusiness(String parameter) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".deletebusiness", parameter);
	}

	@Override
	public List<ItemVO> loaditem() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loaditem");
	}

	@Override
	public int additem(ItemVO itemVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".additem", itemVO);
	}

	@Override
	public int deleteitem(String parameter) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".deleteitem", parameter);
	}

	@Override
	public List<ItemVO> searchib_num(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchib_num", parameter);
	}

	@Override
	public List<ItemVO> searchib_name(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchib_name", parameter);
	}

	@Override
	public List<ItemVO> searchi_num(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchi_num", parameter);
	}

	@Override
	public List<ItemVO> searchi_name(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchi_name", parameter);
	}

	@Override
	public int addwarehouse(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addwarehouse", icsVO);
	}

	@Override
	public int addpayment(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addpayment", icsVO);
	}

	@Override
	public int addbuyhistory(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addbuyhistory", icsVO);
	}

	@Override
	public List<WarehouseVO> loadwarehouse() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadwarehouse");
	}

	@Override
	public List<WarehouseVO> searchwi_num(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchwi_num", parameter);
	}

	@Override
	public List<WarehouseVO> searchwi_name(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchwi_name", parameter);
	}

	@Override
	public List<WarehouseVO> searchwdate(DateVO dateVO) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchwdate", dateVO);
	}

	public List<BuyhistoryVO> loadbuyhistory() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadbuyhistory");
	}

	@Override
	public List<BuyhistoryVO> searchbhi_num(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchbhi_num", parameter);
	}

	@Override
	public List<BuyhistoryVO> searchbhi_name(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchbhi_name", parameter);
	}

	@Override
	public List<BuyhistoryVO> searchbhb_name(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchbhb_name", parameter);
	}

	@Override
	public List<BuyhistoryVO> searchbhdate(DateVO dateVO) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchbhdate", dateVO);
	}

	@Override
	public List<BuyhistoryVO> searchbhwho(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchbhwho", parameter);
	}
	
	@Override
	public List<BuyhistoryVO> searchshi_num(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchshi_num", parameter);
	}

	@Override
	public List<BuyhistoryVO> searchshi_name(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchshi_name", parameter);
	}

	@Override
	public List<BuyhistoryVO> searchshb_name(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchshb_name", parameter);
	}

	@Override
	public List<BuyhistoryVO> searchshdate(DateVO dateVO) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchshdate", dateVO);
	}

	@Override
	public List<BuyhistoryVO> searchshwho(String parameter) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".searchshwho", parameter);
	}

	@Override
	public int subwarehouse(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".subwarehouse", icsVO);
	}

	@Override
	public int addcollect(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addcollect", icsVO);
	}
	
	@Override
	public int addsellhistory(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addsellhistory", icsVO);
	}

	@Override
	public List<UitemVO> loadunstorepopup() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadunstorepopup");
	}

	@Override
	public List<BuyhistoryVO> loadsellhistory() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadsellhistory");
	}

	@Override
	public List<PaymentVO> loadpayment() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadpayment");
	}
	
	@Override
	public List<PaymentVO> loadcollect() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadcollect");
	}
	
	@Override
	public int updatepayment(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updatepayment", paymentVO);
	}
	
	@Override
	public int addpayhistory(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addpayhistory", paymentVO);
	}
		
	@Override
	public int updatecollect(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updatecollect", paymentVO);
	}
	
	@Override
	public int addcolhistory(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addcolhistory", paymentVO);
	}
	
	@Override
	public List<PayhistoryVO> loadpayhistory() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadpayhistory");
	}
	
	@Override
	public List<PayhistoryVO> loadcolhistory() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadcolhistory");
	}
	
	@Override
	public int existcountfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".existcountfinish", icsVO);
	}
	
	@Override
	public int existmoneyfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".existmoneyfinish", icsVO);
	}
	
	@Override
	public int existmoneyfinish1(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".existmoneyfinish1", paymentVO);
	}
	
	@Override
	public int existmoneyfinish2(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".existmoneyfinish2", paymentVO);
	}
	
	@Override
	public int updatestorecountfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updatestorecountfinish", icsVO);
	}

	@Override
	public int addstorecountfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addstorecountfinish", icsVO);
	}
	
	public int updateunstorecountfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updateunstorecountfinish", icsVO);
	}

	@Override
	public int addunstorecountfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addunstorecountfinish", icsVO);
	}
	
	@Override
	public int updatestoremoneyfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updatestoremoneyfinish", icsVO);
	}

	@Override
	public int addstoremoneyfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addstoremoneyfinish", icsVO);
	}
	
	@Override
	public int updateunstoremoneyfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updateunstoremoneyfinish", icsVO);
	}

	@Override
	public int addunstoremoneyfinish(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".addunstoremoneyfinish", icsVO);
	}
	
	@Override
	public List<CountfinishVO> loadcountfinish() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadcountfinish");
	}
	
	@Override
	public List<MoneyfinishVO> loadmoneyfinish() {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".loadmoneyfinish");
	}
	
	@Override
	public int existwarehouse(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".existwarehouse", icsVO);
	}
	
	@Override
	public int updatewarehouse(IcsVO icsVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updatewarehouse", icsVO);
	}
	
	@Override
	public int updatepmoneyfinish(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updatepmoneyfinish", paymentVO);
	}
	
	@Override
	public int updatecmoneyfinish(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".updatecmoneyfinish", paymentVO);
	}
	
	@Override
	public int addpmoneyfinish(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".addpmoneyfinish", paymentVO);
	}
	
	@Override
	public int addcmoneyfinish(PaymentVO paymentVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".addcmoneyfinish", paymentVO);
	}
	
	@Override
	public int finish(DateVO dateVO) {
		return session.update(namespace+".finish1", dateVO) + session.update(namespace+".finish2", dateVO);
	}
	
	@Override
	public int unfinish(DateVO dateVO) {
		return session.update(namespace+".unfinish1", dateVO) + session.update(namespace+".unfinish2", dateVO);
	}

	@Override
	public int checkbuyhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".checkbuyhistory", buyhistoryVO);
	}
	
	@Override
	public int checksellhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".checksellhistory", buyhistoryVO);
	}

	@Override
	public int revisebuyhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisebuyhistory", buyhistoryVO);
	}

	@Override
	public int revisepayment(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisepayment", buyhistoryVO);
	}
	
	@Override
	public int revisewarehouse(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisewarehouse", buyhistoryVO);
	}

	@Override
	public int canclewarehouse(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclewarehouse", buyhistoryVO);
	}

	@Override
	public int canclepayment(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclepayment", buyhistoryVO);
	}

	@Override
	public int canclebuyhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclebuyhistory", buyhistoryVO);
	}

	@Override
	public int canclepayhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclepayhistory", buyhistoryVO);
	}
	
	@Override
	public int revisesellhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisesellhistory", buyhistoryVO);
	}

	@Override
	public int revisecollect(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisecollect", buyhistoryVO);
	}
	
	@Override
	public int revisewarehouse2(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisewarehouse2", buyhistoryVO);
	}

	@Override
	public int canclewarehouse2(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclewarehouse2", buyhistoryVO);
	}

	@Override
	public int canclecollect(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclecollect", buyhistoryVO);
	}

	@Override
	public int canclesellhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclesellhistory", buyhistoryVO);
	}

	@Override
	public int canclecolhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclecolhistory", buyhistoryVO);
	}

	@Override
	public String checkfinish(DateVO dateVO) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".checkfinish", dateVO);
	}

	@Override
	public int checksellwarehouse(HashMap<String, String> map) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".checksellwarehouse", map);
	}

	@Override
	public int revisestorecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisestorecountfinish", buyhistoryVO);
	}
	
	@Override
	public int revisestoreprecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisestoreprecountfinish", buyhistoryVO);
	}

	@Override
	public int revisestoremoneyfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".revisestoremoneyfinish", buyhistoryVO);
	}
	
	@Override
	public int canclestorecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclestorecountfinish", buyhistoryVO);
	}
	
	@Override
	public int canclestoreprecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclestoreprecountfinish", buyhistoryVO);
	}

	@Override
	public int canclestoremoneyfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclestoremoneyfinish", buyhistoryVO);
	}
	
	@Override
	public int reviseunstorecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".reviseunstorecountfinish", buyhistoryVO);
	}
	
	@Override
	public int reviseunstoreprecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".reviseunstoreprecountfinish", buyhistoryVO);
	}

	@Override
	public int reviseunstoremoneyfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".reviseunstoremoneyfinish", buyhistoryVO);
	}
	
	@Override
	public int cancleunstorecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		System.out.print("cancleunstorecountfinish");
		return session.update(namespace+".cancleunstorecountfinish", buyhistoryVO);
	}
	
	@Override
	public int cancleunstoreprecountfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".cancleunstoreprecountfinish", buyhistoryVO);
	}

	@Override
	public int cancleunstoremoneyfinish(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".cancleunstoremoneyfinish", buyhistoryVO);
	}

	@Override
	public List<PayhistoryVO> checkpayhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".checkpayhistory", buyhistoryVO);
	}

	@Override
	public List<PayhistoryVO> checkcolhistory(BuyhistoryVO buyhistoryVO) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".checkcolhistory", buyhistoryVO);
	}

	@Override
	public int canclestorep_moneyfinish(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclestorep_moneyfinish", payhistoryVO);
	}

	@Override
	public int cancleunstorec_moneyfinish(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".cancleunstorec_moneyfinish", payhistoryVO);
	}

	@Override
	public int canclephpayment(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclephpayment", payhistoryVO);
	}

	@Override
	public int canclephmoneyfinish(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclephmoneyfinish", payhistoryVO);
	}

	@Override
	public int canclephpayhistory(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclephpayhistory", payhistoryVO);
	}
	
	@Override
	public int canclechcollect(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclechcollect", payhistoryVO);
	}

	@Override
	public int canclechmoneyfinish(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.update(namespace+".canclechmoneyfinish", payhistoryVO);
	}

	@Override
	public int canclechcolhistory(PayhistoryVO payhistoryVO) {
		// TODO Auto-generated method stub
		return session.delete(namespace+".canclechcolhistory", payhistoryVO);
	}
}
