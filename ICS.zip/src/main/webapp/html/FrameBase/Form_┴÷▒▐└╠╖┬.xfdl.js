﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_지급이력");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_payhistory", this);
            obj._setContents("<ColumnInfo><Column id=\"No\" type=\"INT\" size=\"256\"/><Column id=\"거래처명\" type=\"STRING\" size=\"256\"/><Column id=\"제품번호\" type=\"STRING\" size=\"256\"/><Column id=\"제품명\" type=\"STRING\" size=\"256\"/><Column id=\"지급액\" type=\"INT\" size=\"256\"/><Column id=\"지급날짜\" type=\"STRING\" size=\"256\"/><Column id=\"담당자\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Grid("Grid00","20","100","870","430",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_binddataset("ds_payhistory");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"41\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"117\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"No\"/><Cell col=\"1\" text=\"거래처명\"/><Cell col=\"2\" text=\"제품번호\"/><Cell col=\"3\" text=\"제품명\"/><Cell col=\"4\" text=\"지급액\"/><Cell col=\"5\" text=\"지급날짜\"/><Cell col=\"6\" text=\"담당자\"/></Band><Band id=\"body\"><Cell text=\"bind:No\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:거래처명\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:제품번호\" textAlign=\"center\"/><Cell col=\"3\" text=\"bind:제품명\" textAlign=\"center\"/><Cell col=\"4\" text=\"bind:지급액\" textAlign=\"center\"/><Cell col=\"5\" text=\"bind:지급날짜\" textAlign=\"center\"/><Cell col=\"6\" text=\"bind:담당자\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","20","21","870","69",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_search","650","41","154","32",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","820","35","60","45",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","522","41","118","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">i_num</Col><Col id=\"datacolumn\">제품번호</Col></Row><Row><Col id=\"codecolumn\">i_name</Col><Col id=\"datacolumn\">제품명</Col></Row><Row><Col id=\"codecolumn\">b_name</Col><Col id=\"datacolumn\">거래처명</Col></Row><Row><Col id=\"codecolumn\">who</Col><Col id=\"datacolumn\">담당자</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("제품번호");
            obj.set_value("i_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","35","35","80","40",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("전체보기");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox00","20","540","870","80",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Button("btn_cancle","770","561","100","39",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("지급취소");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static03","341","568","69","25",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("지급액 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_money","410","564","100","32",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_no","75","565","45","32",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static04","33","568","37","25",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text("No :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bname","234","564","80","32",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","146","568","84","25",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("거래처명 : ");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","540","568","80","25",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_text("지급날짜 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_pdate","630","564","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_지급이력.xfdl", function() {
        this.Form_지급이력_onload = function(obj,e)
        {
        	var svcid = "loadpayhistory";
        	var svcurl = "Url::/loadpayhistory";
        	var indataset = "";
        	var outdataset = "ds_payhistory=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadpayhistory";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_reset_onclick = function(obj,e)
        {
        	this.ds_payhistory.filter();
        };

        this.btn_search_onclick = function(obj,e)
        {
        	var kinds = this.Combo00.value;
        	if(!this.edt_search.value){
        		this.alert("검색어를 입력해주세요.");
        	}else{
        		if(kinds=='i_num'){
        			this.ds_payhistory.filter("제품번호.indexOf('" + this.edt_search.value + "') >= 0")
        		}else if(kinds == 'i_name'){
        			this.ds_payhistory.filter("제품명.indexOf('" + this.edt_search.value + "') >= 0")
        		}else if(kinds == 'b_name'){
        			this.ds_payhistory.filter("거래처명.indexOf('" + this.edt_search.value + "') >= 0")
        		}else{
        			this.ds_payhistory.filter("담당자.indexOf('" + this.edt_search.value + "') >= 0")
        		}
        	}
        };

        this.Combo01_onitemchanged = function(obj,e)
        {
        	if(this.Combo01.value == 'r')
        		this.edt_money.set_enable(true);
        	else{
        		this.edt_money.set_enable(false);
        		this.edt_money.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 4));
        	}
        };

        this.Grid00_onselectchanged = function(obj,e)
        {
        	this.edt_no.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 0));
        	this.edt_bname.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 1));
        	this.edt_money.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 4));
        	this.edt_pdate.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 5));
        };

        this.btn_cancle_onclick = function(obj,e)
        {
        	if(this.confirm("지급을 취소 하시겠습니까?")){
        		this.checkfinish1();
        	}
        };

        this.checkfinish1 = function ()
        {
        	var pay_date = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 5);

        	var pay_year = parseInt(pay_date.split("-")[0]);
        	var pay_month = parseInt(pay_date.split("-")[1]);

        	var svcid = "checkfinish";
        	var svcurl = "Url::/checkfinish";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "buy_year=" + pay_year + " buy_month=" + pay_month;
        	var svccallback = "cb_checkfinish1";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.cb_checkfinish1 = function (id,code,message){
        	var pay_date = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 5);

        	var pay_year = parseInt(pay_date.split("-")[0]);
        	var pay_month = parseInt(pay_date.split("-")[1]);

        	var svcid = "canclepayhistory";
        	var svcurl = "Url::/canclepayhistory";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "no=" + this.edt_no.value + " money=" + this.edt_money.value +
        	" pay_year=" + pay_year + " pay_month=" + pay_month;
        	var svccallback = "cb_canclepayhistory";

        	if(code==0){
        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}else{
        		this.alert("해당 월은 이미 마감처리가 완료되었습니다.");
        	}
        }

        this.cb_canclepayhistory = function ()
        {
        	var svcid = "loadpayhistory";
        	var svcurl = "Url::/loadpayhistory";
        	var indataset = "";
        	var outdataset = "ds_payhistory=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadpayhistory";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_지급이력_onload,this);
            this.Grid00.addEventHandler("onselectchanged",this.Grid00_onselectchanged,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.Combo00.addEventHandler("onitemchanged",this.Combo00_onitemchanged,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
            this.btn_cancle.addEventHandler("onclick",this.btn_cancle_onclick,this);
        };

        this.loadIncludeScript("Form_지급이력.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
