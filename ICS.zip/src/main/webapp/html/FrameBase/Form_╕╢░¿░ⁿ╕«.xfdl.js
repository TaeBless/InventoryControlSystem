﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_마감관리");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_finish1", this);
            obj._setContents("<ColumnInfo><Column id=\"년\" type=\"STRING\" size=\"256\"/><Column id=\"월\" type=\"STRING\" size=\"256\"/><Column id=\"제품번호\" type=\"STRING\" size=\"256\"/><Column id=\"제품명\" type=\"STRING\" size=\"256\"/><Column id=\"이월재고\" type=\"INT\" size=\"256\"/><Column id=\"금월출고\" type=\"INT\" size=\"256\"/><Column id=\"금월입고\" type=\"INT\" size=\"256\"/><Column id=\"현재고\" type=\"INT\" size=\"256\"/><Column id=\"마감여부\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new Dataset("ds_finish2", this);
            obj._setContents("<ColumnInfo><Column id=\"년\" type=\"STRING\" size=\"256\"/><Column id=\"월\" type=\"STRING\" size=\"256\"/><Column id=\"사업자번호\" type=\"STRING\" size=\"256\"/><Column id=\"거래처명\" type=\"STRING\" size=\"256\"/><Column id=\"금월구매액\" type=\"INT\" size=\"256\"/><Column id=\"금월지급액\" type=\"INT\" size=\"256\"/><Column id=\"금월판매액\" type=\"INT\" size=\"256\"/><Column id=\"금월수금액\" type=\"INT\" size=\"256\"/><Column id=\"마감여부\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Grid("Grid00","20","90","720","480",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_binddataset("ds_finish1");
            obj.set_autosizingtype("col");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"년\"/><Cell col=\"1\" text=\"월\"/><Cell col=\"2\" text=\"제품번호\"/><Cell col=\"3\" text=\"제품명\"/><Cell col=\"4\" text=\"이월재고\"/><Cell col=\"5\" text=\"금월출고\"/><Cell col=\"6\" text=\"금월입고\"/><Cell col=\"7\" text=\"현재고\"/><Cell col=\"8\" text=\"마감여부\"/></Band><Band id=\"body\"><Cell text=\"bind:년\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:월\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:제품번호\" textAlign=\"center\"/><Cell col=\"3\" text=\"bind:제품명\" textAlign=\"center\"/><Cell col=\"4\" text=\"bind:이월재고\" textAlign=\"center\"/><Cell col=\"5\" text=\"bind:금월출고\" textAlign=\"center\"/><Cell col=\"6\" text=\"bind:금월입고\" textAlign=\"center\"/><Cell col=\"7\" text=\"bind:현재고\" textAlign=\"center\"/><Cell col=\"8\" text=\"bind:마감여부\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid01","760","90","720","480",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_binddataset("ds_finish2");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"41\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"년\"/><Cell col=\"1\" text=\"월\"/><Cell col=\"2\" text=\"사업자번호\"/><Cell col=\"3\" text=\"거래처명\"/><Cell col=\"4\" text=\"금월구매액\"/><Cell col=\"5\" text=\"금월지급액\"/><Cell col=\"6\" text=\"금월판매액\"/><Cell col=\"7\" text=\"금월수금액\"/><Cell col=\"8\" text=\"마감여부\"/></Band><Band id=\"body\"><Cell text=\"bind:년\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:월\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:사업자번호\" textAlign=\"center\"/><Cell col=\"3\" text=\"bind:거래처명\" textAlign=\"center\"/><Cell col=\"4\" text=\"bind:금월구매액\" textAlign=\"center\"/><Cell col=\"5\" text=\"bind:금월지급액\" textAlign=\"center\"/><Cell col=\"6\" text=\"bind:금월판매액\" textAlign=\"center\"/><Cell col=\"7\" text=\"bind:금월수금액\" textAlign=\"center\"/><Cell col=\"8\" text=\"bind:마감여부\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox00","20","581","1461","79",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_year","1015","605","75","31",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_month","1145","605","75","31",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            this.addChild(obj.name, obj);

            obj = new Button("btn_finish","1243","604","100","33",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("마감신청");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","978","604","31","32",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("년 :");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","1109","604","31","32",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("월 :");
            this.addChild(obj.name, obj);

            obj = new Button("btn_cancle","1360","603","100","33",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("마감취소");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static04","1120","666","360","24",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text("마감은 다음 달 초에 하는 것이 규칙이다. -sun-");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","21","11","721","69",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","40","36","100","19",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("<재고마감>");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox02","759","11","721","69",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Static("Static03","780","36","100","19",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("<재화마감>");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","203","30","110","34",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">date</Col><Col id=\"datacolumn\">날짜</Col></Row><Row><Col id=\"codecolumn\">inum</Col><Col id=\"datacolumn\">제품번호</Col></Row><Row><Col id=\"codecolumn\">iname</Col><Col id=\"datacolumn\">제품명</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("날짜");
            obj.set_value("date");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Static("Static_year","324","31","29","30",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_text("년 :");
            this.addChild(obj.name, obj);

            obj = new Static("Static_month","443","30","29","30",null,null,null,null,null,null,this);
            obj.set_taborder("16");
            obj.set_text("월 :");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit_year","353","30","80","34",null,null,null,null,null,null,this);
            obj.set_taborder("17");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit_month","473","30","73","34",null,null,null,null,null,null,this);
            obj.set_taborder("18");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit_search","324","30","222","34",null,null,null,null,null,null,this);
            obj.set_taborder("19");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo01","940","30","114","34",null,null,null,null,null,null,this);
            obj.set_taborder("20");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo01_innerdataset = new nexacro.NormalDataset("Combo01_innerdataset", obj);
            Combo01_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">date</Col><Col id=\"datacolumn\">날짜</Col></Row><Row><Col id=\"codecolumn\">bnum</Col><Col id=\"datacolumn\">사업자번호</Col></Row><Row><Col id=\"codecolumn\">bname</Col><Col id=\"datacolumn\">거래처명</Col></Row></Rows>");
            obj.set_innerdataset(Combo01_innerdataset);
            obj.set_text("날짜");
            obj.set_value("date");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Static("Static_year00","1065","31","29","30",null,null,null,null,null,null,this);
            obj.set_taborder("21");
            obj.set_text("년 :");
            this.addChild(obj.name, obj);

            obj = new Static("Static_month00","1184","30","29","30",null,null,null,null,null,null,this);
            obj.set_taborder("22");
            obj.set_text("월 :");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit_year00","1094","30","80","34",null,null,null,null,null,null,this);
            obj.set_taborder("23");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit_month00","1214","30","73","34",null,null,null,null,null,null,this);
            obj.set_taborder("24");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit_search00","1065","30","222","34",null,null,null,null,null,null,this);
            obj.set_taborder("25");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset00","1370","30","97","34",null,null,null,null,null,null,this);
            obj.set_taborder("26");
            obj.set_text("전체보기");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search00","1294","30","65","34",null,null,null,null,null,null,this);
            obj.set_taborder("27");
            obj.set_text("검색");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","632","30","97","34",null,null,null,null,null,null,this);
            obj.set_taborder("28");
            obj.set_text("전체보기");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","556","30","65","34",null,null,null,null,null,null,this);
            obj.set_taborder("29");
            obj.set_text("검색");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_마감관리.xfdl", function() {
        this.Form_마감관리_onload = function(obj,e)
        {
        	var svcid = "loadcountfinish";
        	var svcurl = "Url::/loadcountfinish";
        	var indataset = "";
        	var outdataset = "ds_finish1=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadcountfinish";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);

        	var svcid = "loadmoneyfinish";
        	var svcurl = "Url::/loadmoneyfinish";
        	var indataset = "";
        	var outdataset = "ds_finish2=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadmoneyfinish";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_finish_onclick = function(obj,e)
        {
        	var d = new Date();

        	var year = this.edt_year.value;
        	var month = this.edt_month.value;

        	var svcid = "finish";
        	var svcurl = "Url::/finish";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "date=" + year + "/" + month;
        	var svccallback = "cb_finish";

        	if(!year || !month){
        		this.alert("년과 월을 모두 입력하세요.");
        	}else if(year > d.getFullYear() || month >= d.getMonth() + 1){
        		this.alert("금월 이상 마감을 하실 수 없습니다.");
        	}else{
        		if(this.confirm(year + "년 " + month + "월을 마감하시겠습니까?")){
        			this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        		}
        	}
        };

        this.cb_finish = function (id,code,message)
        {
        	var svcid = "loadcountfinish";
        	var svcurl = "Url::/loadcountfinish";
        	var indataset = "";
        	var outdataset = "ds_finish1=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadcountfinish";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);

        	var svcid = "loadmoneyfinish";
        	var svcurl = "Url::/loadmoneyfinish";
        	var indataset = "";
        	var outdataset = "ds_finish2=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadmoneyfinish";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_cancle_onclick = function(obj,e)
        {
        	var year = this.edt_year.value;
        	var month = this.edt_month.value;

        	var svcid = "unfinish";
        	var svcurl = "Url::/unfinish";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "date=" + year + "/" + month;
        	var svccallback = "cb_unfinish";

        	if(!year || !month){
        		this.alert("년과 월을 모두 입력하세요.");
        	}else{
        		if(this.confirm(year + "년 " + month + "월 마감을 취소 하시겠습니까?")){
        			this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        		}
        	}
        };

        this.cb_unfinish = function (id,code,message)
        {
        	var svcid = "loadcountfinish";
        	var svcurl = "Url::/loadcountfinish";
        	var indataset = "";
        	var outdataset = "ds_finish1=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadcountfinish";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);

        	var svcid = "loadmoneyfinish";
        	var svcurl = "Url::/loadmoneyfinish";
        	var indataset = "";
        	var outdataset = "ds_finish2=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadmoneyfinish";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };


        this.Combo00_onitemchanged = function(obj,e)
        {
        	var value = this.Combo00.value;

        	if (value == "date")
        	{
        		this.Static_year.set_visible(true);
        		this.Static_month.set_visible(true);
        		this.Edit_year.set_visible(true);
        		this.Edit_month.set_visible(true);
        		this.Edit_search.set_visible(false);
        	}
        	else
        	{
        		this.Static_year.set_visible(false);
        		this.Static_month.set_visible(false);
        		this.Edit_year.set_visible(false);
        		this.Edit_month.set_visible(false);
        		this.Edit_search.set_visible(true
        		);
        	}
        };

        this.Combo01_onitemchanged = function(obj,e)
        {
        	var value = this.Combo01.value;

        	if (value == "date")
        	{
        		this.Static_year00.set_visible(true);
        		this.Static_month00.set_visible(true);
        		this.Edit_year00.set_visible(true);
        		this.Edit_month00.set_visible(true);
        		this.Edit_search00.set_visible(false);
        	}
        	else
        	{
        		this.Static_year00.set_visible(false);
        		this.Static_month00.set_visible(false);
        		this.Edit_year00.set_visible(false);
        		this.Edit_month00.set_visible(false);
        		this.Edit_search00.set_visible(true);
        	}
        };

        this.btn_reset_onclick = function(obj,e)
        {
        	this.ds_finish1.filter();
        };

        this.btn_reset00_onclick = function(obj,e)
        {
        	this.ds_finish2.filter();
        };

        this.btn_search_onclick = function(obj,e)
        {
        	var value = this.Combo00.value;

        	if(value == "date"){
        		if(!this.Edit_year.value || !this.Edit_month.value){
        			this.alert("검색조건을 모두 입력해주세요.");
        		}else{
        			this.ds_finish1.filter("년 == '" + this.Edit_year.value + "' && 월 == '" + this.Edit_month.value + "'");
        		}
        	}else{
        		if(!this.Edit_search.value){
        			this.alert("검색조건을 입력해주세요.");
        		}else{
        			if(value == "inum"){
        				this.ds_finish1.filter("제품번호.indexOf('" + this.Edit_search.value + "') >= 0");
        			}else{
        				this.ds_finish1.filter("제품명.indexOf('" + this.Edit_search.value + "') >= 0");
        			}
        		}
        	}
        };

        this.btn_search00_onclick = function(obj,e)
        {
        	var value = this.Combo01.value;

        	if(value == "date"){
        		if(!this.Edit_year00.value || !this.Edit_month00.value){
        			this.alert("검색조건을 모두 입력해주세요.");
        		}else{
        			this.ds_finish2.filter("년 == '" + this.Edit_year00.value + "' && 월 == '" + this.Edit_month00.value + "'");
        		}
        	}else{
        		if(!this.Edit_search00.value){
        			this.alert("검색조건을 입력해주세요.");
        		}else{
        			if(value == "bnum"){
        				this.ds_finish2.filter("사업자번호.indexOf('" + this.Edit_search00.value + "') >= 0");
        			}else{
        				this.ds_finish2.filter("거래처명.indexOf('" + this.Edit_search00.value + "') >= 0");
        			}
        		}
        	}
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_마감관리_onload,this);
            this.btn_finish.addEventHandler("onclick",this.btn_finish_onclick,this);
            this.btn_cancle.addEventHandler("onclick",this.btn_cancle_onclick,this);
            this.Combo00.addEventHandler("onitemchanged",this.Combo00_onitemchanged,this);
            this.Combo01.addEventHandler("onitemchanged",this.Combo01_onitemchanged,this);
            this.btn_reset00.addEventHandler("onclick",this.btn_reset00_onclick,this);
            this.btn_search00.addEventHandler("onclick",this.btn_search00_onclick,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
        };

        this.loadIncludeScript("Form_마감관리.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
