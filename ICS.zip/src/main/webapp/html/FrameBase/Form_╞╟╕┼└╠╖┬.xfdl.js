﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_판매이력");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_sellhistory", this);
            obj._setContents("<ColumnInfo><Column id=\"No\" type=\"INT\" size=\"256\"/><Column id=\"거래처명\" type=\"STRING\" size=\"256\"/><Column id=\"제품번호\" type=\"STRING\" size=\"256\"/><Column id=\"제품명\" type=\"STRING\" size=\"256\"/><Column id=\"수량\" type=\"INT\" size=\"256\"/><Column id=\"총가격\" type=\"INT\" size=\"256\"/><Column id=\"판매일\" type=\"STRING\" size=\"256\"/><Column id=\"담당자\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Grid("Grid00","20","99","870","431",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_binddataset("ds_sellhistory");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"30\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"44\"/><Column size=\"80\"/><Column size=\"114\"/><Column size=\"64\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"No\"/><Cell col=\"1\" text=\"거래처명\"/><Cell col=\"2\" text=\"제품번호\"/><Cell col=\"3\" text=\"제품명\"/><Cell col=\"4\" text=\"수량\"/><Cell col=\"5\" text=\"총가격\"/><Cell col=\"6\" text=\"판매일\"/><Cell col=\"7\" text=\"담당자\"/></Band><Band id=\"body\"><Cell text=\"bind:No\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:거래처명\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:제품번호\" textAlign=\"center\"/><Cell col=\"3\" text=\"bind:제품명\" textAlign=\"center\"/><Cell col=\"4\" text=\"bind:수량\" textAlign=\"center\"/><Cell col=\"5\" text=\"bind:총가격\" textAlign=\"center\"/><Cell col=\"6\" text=\"bind:판매일\" textAlign=\"center\"/><Cell col=\"7\" text=\"bind:담당자\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox00","21","19","870","70",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","40","37","100","33",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("전체보기");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit02","570","39","234","32",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","820","33","60","45",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","442","39","118","32",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">i_num</Col><Col id=\"datacolumn\">제품번호</Col></Row><Row><Col id=\"codecolumn\">i_name</Col><Col id=\"datacolumn\">제품명</Col></Row><Row><Col id=\"codecolumn\">b_name</Col><Col id=\"datacolumn\">거래처명</Col></Row><Row><Col id=\"codecolumn\">date</Col><Col id=\"datacolumn\">판매날짜</Col></Row><Row><Col id=\"codecolumn\">who</Col><Col id=\"datacolumn\">담당자</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("제품번호");
            obj.set_value("i_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Calendar("Calendar00","570","40","110","31",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Calendar("Calendar01","694","40","112","31",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","680","46","14","22",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("~");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","20","540","870","80",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Button("btn_cancle","770","561","100","39",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("확인");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","182","568","84","25",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text("제품번호 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_inum","270","564","116","32",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static03","411","568","49","25",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("수량 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_count","466","564","101","32",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_no","85","565","65","32",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static04","43","568","37","25",null,null,null,null,null,null,this);
            obj.set_taborder("16");
            obj.set_text("No :");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo01","644","564","112","33",null,null,null,null,null,null,this);
            obj.set_taborder("17");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            obj.set_font("bold 10pt \"Arial\"");
            obj.set_border("1px solid black");
            var Combo01_innerdataset = new nexacro.NormalDataset("Combo01_innerdataset", obj);
            Combo01_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">r</Col><Col id=\"datacolumn\">수정</Col></Row><Row><Col id=\"codecolumn\">c</Col><Col id=\"datacolumn\">취소</Col></Row></Rows>");
            obj.set_innerdataset(Combo01_innerdataset);
            obj.set_text("수정");
            obj.set_value("r");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","30","628","460","22",null,null,null,null,null,null,this);
            obj.set_taborder("18");
            obj.set_text("수정은 수금이 이루어지지 않은 내역에 대해서만 가능합니다.");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_판매이력.xfdl", function() {

        this.Form_판매이력_onload = function(obj,e)
        {
        	var svcid = "loadsellhistory";
        	var svcurl = "Url::/loadsellhistory";
        	var indataset = "";
        	var outdataset = "ds_sellhistory=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadsellhistory";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_reset_onclick = function(obj,e)
        {
        	var svcid = "loadsellhistory";
        	var svcurl = "Url::/loadsellhistory";
        	var indataset = "";
        	var outdataset = "ds_sellhistory=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadsellhistory";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_search_onclick = function(obj,e)
        {
        	var svcid = "searchsellhistory";
        	var svcurl = "Url::/searchsellhistory";
        	var indataset = "";
        	var outdataset = "ds_sellhistory=ds_out";
        	var parameter = "";
        	var svccallback = "cb_searchsellhistory";

        	if(this.Combo00.value=="date"){
        		if(!this.Calendar00.value || !this.Calendar01.value){
        			this.alert("기간을 선택하세요");
        			return;
        		}
        		if(this.Calendar00.value > this.Calendar01.value){
        			this.alert("From날짜가 To날짜 보다 클 수 없습니다.");
        			return;
        		}
        		parameter = "value=" + this.Combo00.value + "/" + this.Calendar00.value + "~" + this.Calendar01.value;
        	}else{
        		if(!this.Edit02.value){
        			this.alert("검색내용을 입력하세요.");
        			return;
        		}
        		parameter = "value=" + this.Combo00.value + "/" + this.Edit02.value;
        	}

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.Combo00_onitemchanged = function(obj,e)
        {
        	if(e.postvalue=="date"){
        		this.Edit02.set_visible(false);
        		this.Calendar00.set_visible(true);
        		this.Calendar01.set_visible(true);
        		this.Static00.set_visible(true);
        	}else{
        		this.Edit02.set_visible(true);
        		this.Calendar00.set_visible(false);
        		this.Calendar01.set_visible(false);
        		this.Static00.set_visible(false);
        	}
        };

        this.Grid00_onselectchanged = function(obj,e)
        {
        	this.edt_no.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 0));
        	this.edt_inum.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 2));
        	this.edt_count.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 4));
        };

        this.btn_cancle_onclick = function(obj,e)
        {
        	if(this.Combo01.value == 'r'){
        		if(!this.edt_count.value){
        			this.alert("변경할 수량을 입력하세요.");
        			return;
        		}
        		var svcid = "checksellwarehouse";
        		var svcurl = "Url::/checksellwarehouse";
        		var indataset = "";
        		var outdataset = "";
        		var parameter = "i_num=" + this.edt_inum.value + " nowcount=" + this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 4) + " revisecount=" + this.edt_count.value;
        		var svccallback = "cb_checksellwarehouse";

        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}
        	else{
        		this.checkfinish2();
        	}
        };

        this.cb_checksellwarehouse = function (id,code,message)
        {
        	if(code == 0)
        		this.checkfinish1();
        	else
        		this.alert("보유한 재고보다 많은 수량을 판매할 수 없습니다.");
        };

        this.checkfinish1 = function ()
        {
        	var buy_date = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 6);

        	var buy_year = parseInt(buy_date.split("-")[0]);
        	var buy_month = parseInt(buy_date.split("-")[1]);

        	var svcid = "checkfinish";
        	var svcurl = "Url::/checkfinish";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "buy_year=" + buy_year + " buy_month=" + buy_month;
        	var svccallback = "cb_checkfinish1";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.cb_checkfinish1 = function (id,code,message){
        	var sell_date = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 6);

        	var sell_year = parseInt(sell_date.split("-")[0]);
        	var sell_month = parseInt(sell_date.split("-")[1]);

        	var svcid = "revisesellhistory";
        	var svcurl = "Url::/revisesellhistory";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "no=" + this.edt_no.value + " i_num=" + this.edt_inum.value + " count=" + this.edt_count.value +
        	" sell_year=" + sell_year + " sell_month=" + sell_month;
        	var svccallback = "cb_revisesellhistory";

        	if(code==0){
        		if(this.confirm("No : " + this.edt_no.value + "\n"
        			+ "제품번호 : " + this.edt_inum.value + "\n"
        			+ "구매일 : " + this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 6) + "\n"
        			+ "해당 제품 구매내역을 수정하시겠습니까?")){
        			this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        		}
        	}else{
        		this.alert("해당 월은 이미 마감처리가 완료되었습니다.");
        	}
        }

        this.cb_revisesellhistory = function (id,code,message)
        {
        	if(code == 0){
        		var svcid = "loadsellhistory";
        		var svcurl = "Url::/loadsellhistory";
        		var indataset = "";
        		var outdataset = "ds_sellhistory=ds_out";
        		var parameter = "";
        		var svccallback = "cb_loadsellhistory";

        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}else{
        		this.alert("해당 판매내역에 대한 수금이 '진행중'이거나 '완료'되었습니다. 판매내역 취소 후 재신청 바랍니다.");
        	}
        };

        this.checkfinish2 = function ()
        {
        	var buy_date = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 6);

        	var buy_year = parseInt(buy_date.split("-")[0]);
        	var buy_month = parseInt(buy_date.split("-")[1]);

        	var svcid = "checkfinish";
        	var svcurl = "Url::/checkfinish";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "buy_year=" + buy_year + " buy_month=" + buy_month;
        	var svccallback = "cb_checkfinish2";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.cb_checkfinish2 = function (id,code,message)
        {
        	var sell_date = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 6);

        	var sell_year = parseInt(sell_date.split("-")[0]);
        	var sell_month = parseInt(sell_date.split("-")[1]);

        	var svcid = "canclesellhistory";
        	var svcurl = "Url::/canclesellhistory";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "no=" + this.edt_no.value + " i_num=" + this.edt_inum.value + " count=" + this.edt_count.value +
        	" sell_year=" + sell_year + " sell_month=" + sell_month;
        	var svccallback = "cb_canclesellhistory";

        	if(code == 0){
        		if(this.confirm("No : " + this.edt_no.value + "\n"
        			+ "제품번호 : " + this.edt_inum.value + "\n"
        			+ "구매일 : " + this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 6) + "\n"
        			+ "해당 제품 구매를 취소하시겠습니까?")){
        			this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        		}
        	}else{
        		this.alert("해당 월은 이미 마감처리가 완료되었습니다.");
        	}
        };

        this.cb_canclesellhistory = function ()
        {
        	var svcid = "loadsellhistory";
        	var svcurl = "Url::/loadsellhistory";
        	var indataset = "";
        	var outdataset = "ds_sellhistory=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadsellhistory";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };
        this.Combo01_onitemchanged = function(obj,e)
        {
        	if(this.Combo01.value == 'r')
        		this.edt_count.set_enable(true);
        	else{
        		this.edt_count.set_enable(false);
        		this.edt_count.set_value(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 4));
        	}
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_판매이력_onload,this);
            this.Grid00.addEventHandler("onselectchanged",this.Grid00_onselectchanged,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.Combo00.addEventHandler("onitemchanged",this.Combo00_onitemchanged,this);
            this.btn_cancle.addEventHandler("onclick",this.btn_cancle_onclick,this);
            this.Combo01.addEventHandler("onitemchanged",this.Combo01_onitemchanged,this);
        };

        this.loadIncludeScript("Form_판매이력.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
