﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Left");
            this.set_titletext("Form_Left");
            this.set_border("0px none, 1px solid black, 0px none, 0px none");
            if (Form == this.constructor)
            {
                this._setFormPosition(180,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new Static("static_00","34","22","100","28",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("창고현황");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_01","33","65","100","30",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("입고신청");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_02","33","110","100","30",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("구매이력");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_03","34","155","100","30",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("지급현황");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_04","33","200","100","30",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("지급이력");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_05","33","245","100","30",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("출고신청");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_06","33","286","100","40",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("판매이력");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_07","33","330","100","40",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("수금현황");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_08","33","373","100","40",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("수금이력");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_09","33","414","100","40",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("마감관리");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_10","33","459","100","40",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("거래처관리");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            obj = new Static("static_11","33","502","100","40",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text("제품관리");
            obj.set_textAlign("center");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",180,980,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_Left.xfdl", function() {
        this.myfunction = function colorinit()
        {
        	this.static_00.set_color("#000000");
        	this.static_01.set_color("#000000");
        	this.static_02.set_color("#000000");
        	this.static_03.set_color("#000000");
        	this.static_04.set_color("#000000");
        	this.static_05.set_color("#000000");
        	this.static_06.set_color("#000000");
        	this.static_07.set_color("#000000");
        	this.static_08.set_color("#000000");
        	this.static_09.set_color("#000000");
        	this.static_10.set_color("#000000");
        	this.static_11.set_color("#000000");
        };

        this.static_00_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_00.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_Work.xfdl");

        };

        this.static_01_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_01.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_입고신청.xfdl");
        };

        this.static_02_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_02.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_구매이력.xfdl");
        };

        this.static_03_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_03.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_지급현황.xfdl");
        };

        this.static_04_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_04.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_지급이력.xfdl");
        };

        this.static_05_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_05.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_출고신청.xfdl");
        };

        this.static_06_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_06.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_판매이력.xfdl");
        };

        this.static_07_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_07.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_수금현황.xfdl");
        };

        this.static_08_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_08.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_수금이력.xfdl");
        };

        this.static_09_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_09.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_마감관리.xfdl");
        };

        this.static_10_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_10.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_Business.xfdl");
        };

        this.static_11_onclick = function(obj,e)
        {
        	this.myfunction();
        	this.static_11.set_color("#ff0000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_제품관리.xfdl");
        };

        this.Form_Left_onload = function(obj,e)
        {
        	this.static_00.set_color("#FF0000");
        };


        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_Left_onload,this);
            this.static_00.addEventHandler("onclick",this.static_00_onclick,this);
            this.static_01.addEventHandler("onclick",this.static_01_onclick,this);
            this.static_02.addEventHandler("onclick",this.static_02_onclick,this);
            this.static_03.addEventHandler("onclick",this.static_03_onclick,this);
            this.static_04.addEventHandler("onclick",this.static_04_onclick,this);
            this.static_05.addEventHandler("onclick",this.static_05_onclick,this);
            this.static_06.addEventHandler("onclick",this.static_06_onclick,this);
            this.static_07.addEventHandler("onclick",this.static_07_onclick,this);
            this.static_08.addEventHandler("onclick",this.static_08_onclick,this);
            this.static_09.addEventHandler("onclick",this.static_09_onclick,this);
            this.static_10.addEventHandler("onclick",this.static_10_onclick,this);
            this.static_11.addEventHandler("onclick",this.static_11_onclick,this);
        };

        this.loadIncludeScript("Form_Left.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
