﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_출고팝업");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(900,320);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_item", this);
            obj._setContents("<ColumnInfo><Column id=\"제품번호\" type=\"STRING\" size=\"256\"/><Column id=\"제품명\" type=\"STRING\" size=\"256\"/><Column id=\"원가\" type=\"INT\" size=\"256\"/><Column id=\"현재고\" type=\"INT\" size=\"256\"/><Column id=\"EA\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("btn_ok","16","263","80","37",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("확인");
            this.addChild(obj.name, obj);

            obj = new Button("btn_cancle","106","263","80","37",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("취소");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox00","16","100","304","150",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","74","120","86","25",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("제품번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_inum","165","116","135","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","91","163","69","25",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("제품명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_iname","165","159","135","32",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","333","16","547","284",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_binddataset("ds_item");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"제품번호\"/><Cell col=\"1\" text=\"제품명\"/><Cell col=\"2\" text=\"원가\"/><Cell col=\"3\" text=\"현재고\"/><Cell col=\"4\" text=\"EA\"/></Band><Band id=\"body\"><Cell text=\"bind:제품번호\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:제품명\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:원가\" textAlign=\"center\"/><Cell col=\"3\" text=\"bind:현재고\" textAlign=\"center\"/><Cell col=\"4\" text=\"bind:EA\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","91","208","64","25",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("현재고 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bname","165","204","135","32",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","16","15","304","73",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","31","24","183","25",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">i_num</Col><Col id=\"datacolumn\">제품번호</Col></Row><Row><Col id=\"codecolumn\">i_name</Col><Col id=\"datacolumn\">제품명</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("제품번호");
            obj.set_value("i_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_search","31","55","183","26",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","230","28","80","49",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","232","263","88","37",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_text("전체보기");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",900,320,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_출고팝업.xfdl", function() {

        this.Grid00_onselectchanged = function(obj,e)
        {
        	this.edt_inum.set_value(this.Grid00.getCellValue(e.row, 0));
        	this.edt_iname.set_value(this.Grid00.getCellValue(e.row, 1));
        	this.edt_bname.set_value(this.Grid00.getCellValue(e.row, 3));
        };

        this.btn_search_onclick = function(obj,e)
        {
        	var index = this.Combo00.index;

        	if(!this.edt_search.value){
        		this.alert("검색조건을 입력하세요.")
        	}else{
        		if(index == '0'){
        			this.ds_item.filter("제품번호.indexOf('" + this.edt_search.value + "') >= 0");
        		}else{
        			this.ds_item.filter("제품명.indexOf('" + this.edt_search.value + "') >= 0");
        		}
        	}
        };

        this.btn_reset_onclick = function(obj,e)
        {
        	this.ds_item.filter();
        };

        this.btn_cancle_onclick = function(obj,e)
        {
        	this.close();
        };

        this.Form_출고팝업_onload = function(obj,e)
        {
        	var svcid = "loadunstorepopup";
        	var svcurl = "Url::/loadunstorepopup";
        	var indataset = "";
        	var outdataset = "ds_item=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadunstorepopup";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_ok_onclick = function(obj,e)
        {
        	var i_num = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 0)
        	var i_name = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 1)
        	var price = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 2)
        	var count = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 3)
        	var ea = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 4)

        	this.close(i_num + "/" + i_name + "/" + price + "/" + count + "/" + ea);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_출고팝업_onload,this);
            this.btn_ok.addEventHandler("onclick",this.btn_ok_onclick,this);
            this.btn_cancle.addEventHandler("onclick",this.btn_cancle_onclick,this);
            this.Grid00.addEventHandler("onselectchanged",this.Grid00_onselectchanged,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
        };

        this.loadIncludeScript("Form_출고팝업.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
