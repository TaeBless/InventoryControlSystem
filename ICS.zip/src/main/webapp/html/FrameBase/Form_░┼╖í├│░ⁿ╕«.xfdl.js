﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_거래처관리");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_business", this);
            obj._setContents("<ColumnInfo><Column id=\"사업자번호\" type=\"STRING\" size=\"256\"/><Column id=\"거래처명\" type=\"STRING\" size=\"256\"/><Column id=\"지역\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new GroupBox("GroupBox00","21","453","919","69",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","45","475","115","25",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("사업자번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_num","150","471","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","297","474","93","25",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("거래처명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_name","383","470","129","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","542","474","128","25",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("지역(시단위) : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_loc","660","470","144","32",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","21","100","919","340",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_binddataset("ds_business");
            obj.set_autofittype("col");
            obj.set_fillareatype("allrow");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"사업자번호\"/><Cell col=\"1\" text=\"거래처명\"/><Cell col=\"2\" text=\"지역\"/></Band><Band id=\"body\"><Cell text=\"bind:사업자번호\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:거래처명\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:지역\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Button("btn_add","824","469","96","37",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("등록");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","21","21","919","69",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_search","660","38","144","32",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","820","36","100","37",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","495","38","153","33",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"datacolumn\">사업자번호</Col><Col id=\"codecolumn\">b_num</Col></Row><Row><Col id=\"datacolumn\">거래처명</Col><Col id=\"codecolumn\">b_name</Col></Row><Row><Col id=\"datacolumn\">지역(시단위)</Col><Col id=\"codecolumn\">b_loc</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("사업자번호");
            obj.set_value("b_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","40","38","100","33",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("전체보기");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_거래처관리.xfdl", function() {
        this.Form_거래처관리_onload = function(obj,e)
        {
        	var svcid = "loadbusiness";
        	var svcurl = "Url::/loadbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadbusiness";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };


        this.btn_search_onclick = function(obj,e)
        {
        	var code = this.Combo00.value;

        	var svcid = "searchbusiness";
        	var svcurl = "Url::/searchbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = code + "=" + code  + "/" + this.edt_search.value;
        	var svccallback = "cb_searchbusiness";

        	if(!this.edt_search.value){
        		this.alert("검색 할 내용을 입력하세요.");
        	}else{
        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}
        };

        this.btn_add_onclick = function(obj,e)
        {
        	if(!this.edt_num.value || !this.edt_name.value || !this.edt_loc.value){
        		this.alert("사업자번호, 거래처명, 위치를 모두 입력해주세요.");
        	}else{
        		for(var i=0; i<this.Grid00.rowcount; i++){
        			if(this.edt_num.value==this.Grid00.getCellValue(i, 0)){
        				this.alert("같은 사업자 번호가 존재합니다.");
        				return;
        			}
        		}

        		var svcid = "addbusiness";
        		var svcurl = "Url::/addbusiness";
        		var indataset = "";
        		var outdataset = "";
        		var parameter = "b_num=" + this.edt_num.value + " b_name="+this.edt_name.value + " b_loc=" + this.edt_loc.value;
        		var svccallback = "cb_addbusiness";

        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}

        };

        this.cb_addbusiness = function(id,code,message){

        	this.edt_num.set_value();
        	this.edt_name.set_value();
        	this.edt_loc.set_value();

        	var svcid = "loadbusiness";
        	var svcurl = "Url::/loadbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadbusiness";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);

        };

        this.btn_reset_onclick = function(obj,e)
        {
        	var svcid = "loadbusiness";
        	var svcurl = "Url::/loadbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadbusiness";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_delete_onclick = function(obj,e)
        {
        	var b_num = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 0);

        	var svcid = "deletebusiness";
        	var svcurl = "Url::/deletebusiness";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "b_num=" + b_num;
        	var svccallback = "cb_deletebusiness";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.cb_deletebusiness = function(id,code,message){

        	var svcid = "loadbusiness";
        	var svcurl = "Url::/loadbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadbusiness";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);

        }

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_거래처관리_onload,this);
            this.btn_add.addEventHandler("onclick",this.btn_add_onclick,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
        };

        this.loadIncludeScript("Form_거래처관리.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
