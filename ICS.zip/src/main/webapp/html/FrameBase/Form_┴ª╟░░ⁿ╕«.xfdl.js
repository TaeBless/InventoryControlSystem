﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_제품관리");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_item", this);
            obj._setContents("<ColumnInfo><Column id=\"제품번호\" type=\"STRING\" size=\"256\"/><Column id=\"제품명\" type=\"STRING\" size=\"256\"/><Column id=\"사업자번호\" type=\"STRING\" size=\"256\"/><Column id=\"거래처명\" type=\"STRING\" size=\"256\"/><Column id=\"단가\" type=\"INT\" size=\"256\"/><Column id=\"EA\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new GroupBox("GroupBox00","21","494","949","166",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","35","518","115","25",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("사업자번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bnum","140","514","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","297","517","93","25",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("거래처명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bname","383","513","129","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","542","517","128","25",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("지역(시단위) : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bloc","660","513","144","32",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Button("btn_business","840","509","110","37",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("거래처팝업");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","20","117","950","367",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_binddataset("ds_item");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"33\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"제품번호\"/><Cell col=\"1\" text=\"제품명\"/><Cell col=\"2\" text=\"사업자번호\"/><Cell col=\"3\" text=\"거래처명\"/><Cell col=\"4\" text=\"단가\"/><Cell col=\"5\" text=\"EA\"/></Band><Band id=\"body\"><Cell text=\"bind:제품번호\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:제품명\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:사업자번호\" textAlign=\"center\"/><Cell col=\"3\" text=\"bind:거래처명\" textAlign=\"center\"/><Cell col=\"4\" text=\"bind:단가\" textAlign=\"center\"/><Cell col=\"5\" text=\"bind:EA\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Button("btn_iadd","844","610","106","37",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("제품등록");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static03","48","567","115","25",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text("제품번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_inum","140","563","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static04","310","566","80","25",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("제품명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_iname","381","562","129","32",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static05","552","566","61","25",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_text("단가 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_iprice","606","562","144","32",null,null,null,null,null,null,this);
            obj.set_taborder("16");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static06","793","567","47","25",null,null,null,null,null,null,this);
            obj.set_taborder("17");
            obj.set_text("EA :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_iea","839","562","111","32",null,null,null,null,null,null,this);
            obj.set_taborder("18");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","22","20","948","84",null,null,null,null,null,null,this);
            obj.set_taborder("20");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","845","46","106","37",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("제품검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","40","45","100","33",null,null,null,null,null,null,this);
            obj.set_taborder("19");
            obj.set_text("전체보기");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","547","49","147","30",null,null,null,null,null,null,this);
            obj.set_taborder("21");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">i_num</Col><Col id=\"datacolumn\">제품번호</Col></Row><Row><Col id=\"codecolumn\">i_name</Col><Col id=\"datacolumn\">제품명</Col></Row><Row><Col id=\"codecolumn\">b_num</Col><Col id=\"datacolumn\">사업자번호</Col></Row><Row><Col id=\"codecolumn\">b_name</Col><Col id=\"datacolumn\">사업자명</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("제품번호");
            obj.set_value("i_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_search","704","48","132","31",null,null,null,null,null,null,this);
            obj.set_taborder("22");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_제품관리.xfdl", function() {
        this.btn_reset_onclick = function(obj,e)
        {
        	var svcid = "loaditem";
        	var svcurl = "Url::/loaditem";
        	var indataset = "";
        	var outdataset = "ds_item=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loaditem";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_delete_onclick = function(obj,e)
        {
        	var i_num = this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 0);

        	var svcid = "deleteitem";
        	var svcurl = "Url::/deleteitem";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "i_num=" + i_num;
        	var svccallback = "cb_deleteitem";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.cb_deleteitem = function ()
        {
        	var svcid = "loaditem";
        	var svcurl = "Url::/loaditem";
        	var indataset = "";
        	var outdataset = "ds_item=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loaditem";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_business_onclick = function(obj,e)
        {
        	var objChildFrame = new ChildFrame();
            objChildFrame.init("chf_popup1"
                              , 0
                              , 0
                              , 532
                              , 338
                              , null
                              , null
                              , "FrameBase::Form_거래처팝업.xfdl");

            objChildFrame.set_dragmovetype("all");
            objChildFrame.set_openalign("center middle");
        	objChildFrame.set_resizable(false);
            objChildFrame.set_overlaycolor("RGBA(196,196,196,0.5)")

            objChildFrame.showModal(this.getOwnerFrame()
                                  , null
                                  , this
                                  , "callbackpopup");
        };

        this.callbackpopup = function(strPopupID,strReturn)
        {
        	if(strReturn != null){
        		var strArray = strReturn.split("/");
        		this.edt_bnum.set_value(strArray[0]);
        		this.edt_bname.set_value(strArray[1]);
        		this.edt_bloc.set_value(strArray[2]);
        	}
        };

        this.btn_search_onclick = function(obj,e)
        {
        	if(!this.edt_search.value){
        		this.alert("검색내용을 입력하세요.");
        	}else{
        		var value = this.Combo00.value + "/" + this.edt_search.value;

        		var svcid = "searchitem";
        		var svcurl = "Url::/searchitem";
        		var indataset = "";
        		var outdataset = "ds_item=ds_out";
        		var parameter = "paramter=" + value;
        		var svccallback = "cb_searchitem";

        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}
        };

        this.btn_iadd_onclick = function(obj,e)
        {
        	if(!this.edt_bnum.value || !this.edt_inum.value || !this.edt_iname.value || !this.edt_iprice.value || !this.edt_iea.value){
        		this.alert("모든 항목을 입력해주세요");
        		return;
        	}else{

        		var svcid = "additem";
        		var svcurl = "Url::/additem";
        		var indataset = "";
        		var outdataset = "";
        		var parameter = "i_num=" + this.edt_inum.value + " i_name=" + this.edt_iname.value + " b_num=" + this.edt_bnum.value + " b_name=" +
        		this.edt_bname.value + " price=" + this.edt_iprice.value + " ea=" + this.edt_iea.value;
        		var svccallback = "cb_additem";

        		for(var i=0; i<this.Grid00.rowcount; i++){
        			if(this.Grid00.getCellValue(i, 0) == this.edt_inum.value){
        				this.alert("동일한 제품이 이미 등록 되어있습니다. 제품번호를 확인하세요.");
        				return;
        			}
        		}

        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);

        	}
        };

        this.cb_additem = function(id,code,message){

        	this.edt_inum.set_value();
        	this.edt_iname.set_value();
        	this.edt_iprice.set_value();
        	this.edt_iea.set_value();

        	var svcid = "loaditem";
        	var svcurl = "Url::/loaditem";
        	var indataset = "";
        	var outdataset = "ds_item=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loaditem";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        }

        this.Form_제품관리_onload = function(obj,e)
        {
        	var svcid = "loaditem";
        	var svcurl = "Url::/loaditem";
        	var indataset = "";
        	var outdataset = "ds_item=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loaditem";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.Grid00_onselectchanged = function(obj,e)
        {

        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_제품관리_onload,this);
            this.btn_business.addEventHandler("onclick",this.btn_business_onclick,this);
            this.Grid00.addEventHandler("onselectchanged",this.Grid00_onselectchanged,this);
            this.btn_iadd.addEventHandler("onclick",this.btn_iadd_onclick,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
        };

        this.loadIncludeScript("Form_제품관리.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
