﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Work");
            this.set_titletext("Form_Work");
            if (Form == this.constructor)
            {
                this._setFormPosition(1120,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_warehouse", this);
            obj._setContents("<ColumnInfo><Column id=\"No\" type=\"INT\" size=\"256\"/><Column id=\"제품번호\" type=\"STRING\" size=\"256\"/><Column id=\"제품명\" type=\"STRING\" size=\"256\"/><Column id=\"EA\" type=\"STRING\" size=\"256\"/><Column id=\"수량\" type=\"INT\" size=\"256\"/><Column id=\"최근입출고일\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Grid("Grid00","21","100","870","480",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_binddataset("ds_warehouse");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj.set_font("14px/normal \"배달의민족 주아\"");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"22\"/><Column size=\"57\"/><Column size=\"57\"/><Column size=\"20\"/><Column size=\"41\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"No\"/><Cell col=\"1\" text=\"제품번호\"/><Cell col=\"2\" text=\"제품명\"/><Cell col=\"3\" text=\"EA\"/><Cell col=\"4\" text=\"수량\"/><Cell col=\"5\" text=\"최근입출고일\"/></Band><Band id=\"body\"><Cell text=\"bind:No\" textAlign=\"center\" font=\"18px/normal &quot;배달의민족 주아&quot;\"/><Cell col=\"1\" text=\"bind:제품번호\" textAlign=\"center\" font=\"18px/normal &quot;배달의민족 주아&quot;\"/><Cell col=\"2\" text=\"bind:제품명\" textAlign=\"center\" font=\"18px/normal &quot;배달의민족 주아&quot;\"/><Cell col=\"3\" text=\"bind:EA\" textAlign=\"center\" font=\"18px/normal &quot;배달의민족 주아&quot;\"/><Cell col=\"4\" text=\"bind:수량\" textAlign=\"center\" font=\"18px/normal &quot;배달의민족 주아&quot;\"/><Cell col=\"5\" text=\"bind:최근입출고일\" textAlign=\"center\" font=\"18px/normal &quot;배달의민족 주아&quot;\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox00","20","21","870","69",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            this.addChild(obj.name, obj);

            obj = new Edit("Edit02","570","41","234","32",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","820","35","60","45",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","442","41","118","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">i_num</Col><Col id=\"datacolumn\">제품번호</Col></Row><Row><Col id=\"codecolumn\">i_name</Col><Col id=\"datacolumn\">제품명</Col></Row><Row><Col id=\"codecolumn\">date</Col><Col id=\"datacolumn\">입출고기간</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("제품번호");
            obj.set_value("i_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Calendar("Calendar00","570","42","110","31",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Calendar("Calendar01","694","42","112","31",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","680","48","14","22",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("~");
            obj.set_visible("false");
            this.addChild(obj.name, obj);

            obj = new Button("Button00","35","35","80","40",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("전체보기");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1120,980,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_Work.xfdl", function() {

        this.Form_Work_onload = function(obj,e)
        {
        	var svcid = "loadwarehouse";
        	var svcurl = "Url::/loadwarehouse";
        	var indataset = "";
        	var outdataset = "ds_warehouse=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadwarehouse";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.Combo00_onitemchanged = function(obj,e)
        {
        	if(e.postvalue=="date"){
        		this.Edit02.set_visible(false);
        		this.Calendar00.set_visible(true);
        		this.Calendar01.set_visible(true);
        		this.Static00.set_visible(true);
        	}else{
        		this.Edit02.set_visible(true);
        		this.Calendar00.set_visible(false);
        		this.Calendar01.set_visible(false);
        		this.Static00.set_visible(false);
        	}
        };

        this.btn_search_onclick = function(obj,e)
        {
        	var svcid = "searchwarehouse";
        	var svcurl = "Url::/searchwarehouse";
        	var indataset = "";
        	var outdataset = "ds_warehouse=ds_out";
        	var parameter = "";
        	var svccallback = "cb_searchwarehouse";

        	if(this.Combo00.value=="date"){
        		if(!this.Calendar00.value || !this.Calendar01.value){
        			this.alert("기간을 선택하세요");
        			return;
        		}
        		if(this.Calendar00.value > this.Calendar01.value){
        			this.alert("From날짜가 To날짜 보다 클 수 없습니다.");
        			return;
        		}
        		parameter = "value=" + this.Combo00.value + "/" + this.Calendar00.value + "~" + this.Calendar01.value;
        	}else{
        		if(!this.Edit02.value){
        			this.alert("검색내용을 입력하세요.");
        			return;
        		}
        		parameter = "value=" + this.Combo00.value + "/" + this.Edit02.value;
        	}

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.Button00_onclick = function(obj,e)
        {
        	var svcid = "loadwarehouse";
        	var svcurl = "Url::/loadwarehouse";
        	var indataset = "";
        	var outdataset = "ds_warehouse=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadwarehouse";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_Work_onload,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.Combo00.addEventHandler("onitemchanged",this.Combo00_onitemchanged,this);
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
        };

        this.loadIncludeScript("Form_Work.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
