﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_출고신청");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new GroupBox("GroupBox00","21","20","949","189",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","35","105","115","25",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("사업자번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bnum","141","101","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","297","104","93","25",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("거래처명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bname","383","100","129","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","552","104","109","25",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("지역(시단위) : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bloc","670","100","144","32",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Button("btn_sub","864","219","106","37",null,null,null,null,null,null,this);
            obj.set_taborder("25");
            obj.set_text("출고");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Button("btn_ipopup","844","37","106","37",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("창고팝업");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static03","52","44","78","25",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("제품번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_inum","141","40","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static04","283","43","67","25",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("제품명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_iname","354","39","106","32",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static05","671","43","49","25",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_text("원가 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_price","725","39","100","32",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static06","483","44","67","25",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_text("현재고 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_count","551","39","99","32",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static08","571","161","80","25",null,null,null,null,null,null,this);
            obj.set_taborder("16");
            obj.set_text("수금기한 : ");
            this.addChild(obj.name, obj);

            obj = new Calendar("cal_deadline","661","157","154","34",null,null,null,null,null,null,this);
            obj.set_taborder("23");
            this.addChild(obj.name, obj);

            obj = new Static("Static09","329","163","44","25",null,null,null,null,null,null,this);
            obj.set_taborder("17");
            obj.set_text("수량 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_icount","383","159","130","32",null,null,null,null,null,null,this);
            obj.set_taborder("21");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static07","89","163","44","25",null,null,null,null,null,null,this);
            obj.set_taborder("18");
            obj.set_text("정가 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_rprice","140","159","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("19");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new Button("btn_business","844","98","106","37",null,null,null,null,null,null,this);
            obj.set_taborder("20");
            obj.set_text("거래처팝업");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static10","26","219","574","51",null,null,null,null,null,null,this);
            obj.set_taborder("22");
            obj.set_text("창고에 있는 항목 중에서 출고가 가능합니다.\r\n모든 항목을 입력해야합니다.");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_출고신청.xfdl", function() {

        this.btn_sub_onclick = function(obj,e)
        {
        	var i_num = this.edt_inum.value;
        	var i_name = this.edt_iname.value;
        	var count = this.edt_icount.value;
        	var b_num = this.edt_bnum.value;
        	var b_name = this.edt_bname.value;
        	var rprice = this.edt_rprice.value;
        	var ddate = this.cal_deadline.value;

        	var svcid = "unstoring";
        	var svcurl = "Url::/unstoring";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "i_num=" + i_num + " i_name=" + i_name + " b_num=" + b_num + " b_name=" + b_name + " rprice=" + rprice +
        	" count=" + count + " ddate=" + ddate;
        	var svccallback = "cb_unstoring";

        	if(!i_num || !b_num || !rprice || !count || !ddate){
        		this.alert("모든 항목을 입력해주세요.");
        	}else{
        		if(parseInt(this.edt_count.value) < parseInt(count)){
        			this.alert("현재고보다 많은 수량을 출고 할 수 없습니다.");
        		}else{
        			this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        		}
        	}
        };

        this.cb_unstoring = function(strPopupID,strReturn)
        {
        	this.edt_icount.set_value();
        	this.edt_rprice.set_value();
        	this.cal_deadline.set_value();
        }

        this.btn_ipopup_onclick = function(obj,e)
        {
        	var objChildFrame = new ChildFrame();
            objChildFrame.init("chf_popup"
                              , 0
                              , 0
                              , 532
                              , 338
                              , null
                              , null
                              , "FrameBase::Form_출고팝업.xfdl");

            objChildFrame.set_dragmovetype("all");
            objChildFrame.set_openalign("center middle");
        	objChildFrame.set_resizable(false);
            objChildFrame.set_overlaycolor("RGBA(196,196,196,0.5)")

            objChildFrame.showModal(this.getOwnerFrame()
                                  , null
                                  , this
                                  , "callbackpopup1");
        };

        this.callbackpopup1 = function(strPopupID,strReturn)
        {
        	if(strReturn != null){
        		var str = strReturn.split("/");
        		this.edt_inum.set_value(str[0]);
        		this.edt_iname.set_value(str[1]);
        		this.edt_price.set_value(str[2]);
        		this.edt_count.set_value(str[3]);
        	}
        };

        this.btn_business_onclick = function(obj,e)
        {
        	var objChildFrame = new ChildFrame();
            objChildFrame.init("chf_popup1"
                              , 0
                              , 0
                              , 532
                              , 338
                              , null
                              , null
                              , "FrameBase::Form_거래처팝업.xfdl");

            objChildFrame.set_dragmovetype("all");
            objChildFrame.set_openalign("center middle");
        	objChildFrame.set_resizable(false);
            objChildFrame.set_overlaycolor("RGBA(196,196,196,0.5)")

            objChildFrame.showModal(this.getOwnerFrame()
                                  , null
                                  , this
                                  , "callbackpopup2");
        };

        this.callbackpopup2 = function(strPopupID,strReturn)
        {
        	if(strReturn != null){
        		var strArray = strReturn.split("/");
        		this.edt_bnum.set_value(strArray[0]);
        		this.edt_bname.set_value(strArray[1]);
        		this.edt_bloc.set_value(strArray[2]);
        	}
        };


        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.btn_sub.addEventHandler("onclick",this.btn_sub_onclick,this);
            this.btn_ipopup.addEventHandler("onclick",this.btn_ipopup_onclick,this);
            this.btn_business.addEventHandler("onclick",this.btn_business_onclick,this);
        };

        this.loadIncludeScript("Form_출고신청.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
