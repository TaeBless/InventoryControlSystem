﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_수금현황");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_collect", this);
            obj._setContents("<ColumnInfo><Column id=\"No\" type=\"INT\" size=\"256\"/><Column id=\"거래처명\" type=\"STRING\" size=\"256\"/><Column id=\"제품번호\" type=\"STRING\" size=\"256\"/><Column id=\"제품명\" type=\"STRING\" size=\"256\"/><Column id=\"총수금액\" type=\"INT\" size=\"256\"/><Column id=\"수금한금액\" type=\"INT\" size=\"256\"/><Column id=\"남은금액\" type=\"INT\" size=\"256\"/><Column id=\"수금기한\" type=\"STRING\" size=\"256\"/><Column id=\"상태\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Grid("Grid00","20","99","870","391",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_binddataset("ds_collect");
            obj.set_autofittype("col");
            obj.set_fillareatype("linerow");
            obj.set_scrollbartype("none default");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"43\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"77\"/><Column size=\"80\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"No\"/><Cell col=\"1\" text=\"거래처명\"/><Cell col=\"2\" text=\"제품번호\"/><Cell col=\"3\" text=\"제품명\"/><Cell col=\"4\" text=\"총수금액\"/><Cell col=\"5\" text=\"수금한금액\"/><Cell col=\"6\" text=\"남은금액\"/><Cell col=\"7\" text=\"수금기한\"/><Cell col=\"8\" text=\"상태\"/></Band><Band id=\"body\"><Cell text=\"bind:No\" textAlign=\"center\"/><Cell col=\"1\" text=\"bind:거래처명\" textAlign=\"center\"/><Cell col=\"2\" text=\"bind:제품번호\" textAlign=\"center\"/><Cell col=\"3\" text=\"bind:제품명\" textAlign=\"center\"/><Cell col=\"4\" text=\"bind:총수금액\" textAlign=\"center\"/><Cell col=\"5\" text=\"bind:수금한금액\" textAlign=\"center\"/><Cell col=\"6\" text=\"bind:남은금액\" textAlign=\"center\"/><Cell col=\"7\" text=\"bind:수금기한\" textAlign=\"center\"/><Cell col=\"8\" text=\"expr:수금한금액==0 ? '미수금' : 남은금액==0 ? '수금완료' : '수금중'\" textAlign=\"center\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox00","20","501","871","79",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","184","529","95","25",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("거래처명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_bname","271","525","99","32",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","406","528","75","25",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("제품명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_iname","474","524","96","32",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","601","528","78","25",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("수금액 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_money","669","524","101","32",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            this.addChild(obj.name, obj);

            obj = new Button("btn_collect","783","522","90","37",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("수금");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_no","85","525","65","32",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static03","43","528","37","25",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("No :");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","20","21","870","69",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_search","650","41","154","32",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","820","35","60","45",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text("검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","522","41","118","32",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">i_num</Col><Col id=\"datacolumn\">제품번호</Col></Row><Row><Col id=\"codecolumn\">i_name</Col><Col id=\"datacolumn\">제품명</Col></Row><Row><Col id=\"codecolumn\">b_name</Col><Col id=\"datacolumn\">거래처명</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("제품번호");
            obj.set_value("i_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","35","35","80","40",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_text("전체보기");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_수금현황.xfdl", function() {
        this.Form_수금현황_onload = function(obj,e)
        {
        	var svcid = "loadcollect";
        	var svcurl = "Url::/loadcollect";
        	var indataset = "";
        	var outdataset = "ds_collect=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadcollect";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.Grid00_onselectchanged = function(obj,e)
        {
        	this.edt_no.set_value(this.Grid00.getCellText(this.Grid00.getSelectedRows(), 0));
        	this.edt_bname.set_value(this.Grid00.getCellText(this.Grid00.getSelectedRows(), 1));
        	this.edt_iname.set_value(this.Grid00.getCellText(this.Grid00.getSelectedRows(), 3));
        };

        this.btn_reset_onclick = function(obj,e)
        {
        	this.ds_collect.filter();
        };

        this.btn_collect_onclick = function(obj,e)
        {
        	var svcid = "collect";
        	var svcurl = "Url::/collect";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "id=" + this.edt_no.value + " money=" + this.edt_money.value;
        	var svccallback = "cb_collect";

        	if(!this.edt_money.value){
        		this.alert("수금액을 입력하세요.");
        	}else if(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 8) == "수금완료"){
        		this.alert("수금이 이미 완료된 내역입니다.");
        	}else if(this.Grid00.getCellValue(this.Grid00.getSelectedRows(), 6) < parseInt(this.edt_money.value)){
        		this.alert("남은 금액보다 더 큰 수금액을 수금 할 수 없습니다.");
        	}else{
        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}
        };

        this.cb_collect = function(id,code,message)
        {
        	var svcid = "loadcollect";
        	var svcurl = "Url::/loadcollect";
        	var indataset = "";
        	var outdataset = "ds_collect=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadcollect";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };


        this.btn_search_onclick = function(obj,e)
        {
        	var kinds = this.Combo00.value;
        	if(kinds=='i_num'){
        		this.ds_collect.filter("제품번호.indexOf('" + this.edt_search.value + "') >= 0")
        	}else if(kinds == 'i_name'){
        		this.ds_collect.filter("제품명.indexOf('" + this.edt_search.value + "') >= 0")
        	}else if(kinds == 'b_name'){
        		this.ds_collect.filter("거래처명.indexOf('" + this.edt_search.value + "') >= 0")
        	}
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_수금현황_onload,this);
            this.Grid00.addEventHandler("onselectchanged",this.Grid00_onselectchanged,this);
            this.btn_collect.addEventHandler("onclick",this.btn_collect_onclick,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.Combo00.addEventHandler("onitemchanged",this.Combo00_onitemchanged,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
        };

        this.loadIncludeScript("Form_수금현황.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
