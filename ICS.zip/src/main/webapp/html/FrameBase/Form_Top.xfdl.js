﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Top");
            this.set_titletext("Form_Top");
            this.set_border("0px none, 0px none, 1px solid black");
            if (Form == this.constructor)
            {
                this._setFormPosition(1700,100);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new Static("Static00","100","10","240","79",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("SunTube");
            obj.set_font("normal 48pt/normal \"배달의민족 주아\"");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("ImageViewer00","11","6","79","86",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_stretch("fit");
            obj.set_text("");
            obj.set_visible("true");
            obj.set_image("URL(\"imagerc::SUNTUBE.jpg\")");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","340","10","30","28",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("KR");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("ImageViewer01","1555","28","45","45",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_image("URL(\"imagerc::알림.png\")");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("ImageViewer02","1620","28","40","45",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_image("URL(\"imagerc::태양.png\")");
            obj.set_text("");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1700,100,this,function(p){});
            obj.set_stepcount("0");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_Top.xfdl", function() {
        this.ImageViewer00_onclick = function(obj,e)
        {
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.WorkFrame.set_formurl("FrameBase::Form_Work.xfdl");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_00.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_01.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_02.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_03.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_04.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_05.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_06.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_07.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_08.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_09.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_10.set_color("#000000");
        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_11.set_color("#000000");

        	nexacro.getApplication().mainframe.VFrameSet00.HFrameSet00.LeftFrame.form.static_00.set_color("#ff0000");
        };

        this.ImageViewer01_onclick = function(obj,e)
        {

        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Static00.addEventHandler("onclick",this.Static00_onclick,this);
            this.ImageViewer00.addEventHandler("onclick",this.ImageViewer00_onclick,this);
            this.ImageViewer01.addEventHandler("onclick",this.ImageViewer01_onclick,this);
        };

        this.loadIncludeScript("Form_Top.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
