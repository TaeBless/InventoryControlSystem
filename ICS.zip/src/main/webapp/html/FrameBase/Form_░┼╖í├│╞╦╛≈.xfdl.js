﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_거래처팝업");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(780,360);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_business", this);
            obj._setContents("<ColumnInfo><Column id=\"사업자번호\" type=\"STRING\" size=\"256\"/><Column id=\"거래처명\" type=\"STRING\" size=\"256\"/><Column id=\"지역\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("btn_ok","16","303","80","37",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("확인");
            this.addChild(obj.name, obj);

            obj = new Button("btn_cancle","106","303","80","37",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("취소");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox00","16","106","304","174",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","40","130","115","25",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("사업자번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_num","150","126","150","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","58","179","81","25",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("거래처명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_name","150","175","150","32",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","28","228","128","25",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_text("지역(시단위) : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_loc","150","224","150","32",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","333","16","427","324",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_binddataset("ds_business");
            obj.set_autofittype("col");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/></Columns><Rows><Row band=\"head\" size=\"24\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"사업자번호\"/><Cell col=\"1\" text=\"거래처명\"/><Cell col=\"2\" text=\"지역\"/></Band><Band id=\"body\"><Cell text=\"bind:사업자번호\"/><Cell col=\"1\" text=\"bind:거래처명\"/><Cell col=\"2\" text=\"bind:지역\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new GroupBox("GroupBox01","16","16","304","79",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            this.addChild(obj.name, obj);

            obj = new Button("btn_search","230","28","80","55",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("검색");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Combo("Combo00","34","25","173","28",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            var Combo00_innerdataset = new nexacro.NormalDataset("Combo00_innerdataset", obj);
            Combo00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">b_num</Col><Col id=\"datacolumn\">사업자번호</Col></Row><Row><Col id=\"codecolumn\">b_name</Col><Col id=\"datacolumn\">거래처명</Col></Row><Row><Col id=\"codecolumn\">b_loc</Col><Col id=\"datacolumn\">지역</Col></Row></Rows>");
            obj.set_innerdataset(Combo00_innerdataset);
            obj.set_text("사업자번호");
            obj.set_value("b_num");
            obj.set_index("0");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_search","34","59","173","28",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            this.addChild(obj.name, obj);

            obj = new Button("btn_reset","240","303","80","37",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_text("전체보기");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",780,360,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_거래처팝업.xfdl", function() {
        this.Form_거래처팝업_onload = function(obj,e)
        {
        	var svcid = "loadbusiness";
        	var svcurl = "Url::/loadbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadbusiness";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        this.btn_search_onclick = function(obj,e)
        {
        	var code = this.Combo00.value;

        	var svcid = "searchbusiness";
        	var svcurl = "Url::/searchbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = code + "=" + code  + "/" + this.edt_search.value;
        	var svccallback = "cb_searchbusiness";

        	if(!this.edt_search.value){
        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}else{
        		this.alert("검색 할 내용을 입력하세요.");
        	}
        };

        this.btn_ok_onclick = function(obj,e)
        {
        	this.close(this.edt_num.value + "/" + this.edt_name.value + "/" + this.edt_loc.value);
        };

        this.btn_cancle_onclick = function(obj,e)
        {
        	this.close();
        };



        this.Grid00_onselectchanged = function(obj,e)
        {
        	var b_num = this.Grid00.getCellValue(e.row, 0);
        	var b_name = this.Grid00.getCellValue(e.row, 1);
        	var b_loc = this.Grid00.getCellValue(e.row, 2);

        	this.edt_num.set_value(b_num);
        	this.edt_name.set_value(b_name);
        	this.edt_loc.set_value(b_loc);
        };

        this.btn_reset_onclick = function(obj,e)
        {
        	var svcid = "loadbusiness";
        	var svcurl = "Url::/loadbusiness";
        	var indataset = "";
        	var outdataset = "ds_business=ds_out";
        	var parameter = "";
        	var svccallback = "cb_loadbusiness";

        	this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Form_거래처팝업_onload,this);
            this.btn_ok.addEventHandler("onclick",this.btn_ok_onclick,this);
            this.btn_cancle.addEventHandler("onclick",this.btn_cancle_onclick,this);
            this.Grid00.addEventHandler("onselectchanged",this.Grid00_onselectchanged,this);
            this.btn_search.addEventHandler("onclick",this.btn_search_onclick,this);
            this.btn_reset.addEventHandler("onclick",this.btn_reset_onclick,this);
        };

        this.loadIncludeScript("Form_거래처팝업.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
