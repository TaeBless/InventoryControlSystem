﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_입고신청");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1740,980);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new GroupBox("GroupBox00","21","20","949","189",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","30","105","95","25",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("사업자번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_num","140","101","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static01","293","104","87","25",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("거래처명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_name","382","100","129","32",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Button("btn_add","864","219","106","37",null,null,null,null,null,null,this);
            obj.set_taborder("19");
            obj.set_text("입고");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Button("btn_ipopup","834","90","106","37",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_text("제품팝업");
            obj.set_defaultbutton("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static03","48","44","82","25",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("제품번호 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_inum","140","40","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static04","310","43","80","25",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_text("제품명 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_iname","381","39","129","32",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static05","552","43","61","25",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.set_text("단가 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_price","606","39","144","32",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static06","783","44","47","25",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_text("EA :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_ea","829","39","111","32",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_enable("false");
            this.addChild(obj.name, obj);

            obj = new Static("Static07","64","161","66","25",null,null,null,null,null,null,this);
            obj.set_taborder("14");
            obj.set_text("할인액 :");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_sale","138","157","120","32",null,null,null,null,null,null,this);
            obj.set_taborder("15");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static08","553","158","87","25",null,null,null,null,null,null,this);
            obj.set_taborder("18");
            obj.set_text("지급기한 : ");
            this.addChild(obj.name, obj);

            obj = new Calendar("cal_deadline","645","154","154","34",null,null,null,null,null,null,this);
            obj.set_taborder("17");
            this.addChild(obj.name, obj);

            obj = new Static("Static09","325","160","59","25",null,null,null,null,null,null,this);
            obj.set_taborder("20");
            obj.set_text("수량 : ");
            this.addChild(obj.name, obj);

            obj = new Edit("edt_icount","381","156","129","32",null,null,null,null,null,null,this);
            obj.set_taborder("16");
            obj.set_enable("true");
            this.addChild(obj.name, obj);

            obj = new Static("Static02","21","220","549","70",null,null,null,null,null,null,this);
            obj.set_taborder("21");
            obj.set_text("모든 항목을 입력해야합니다.\r\n할인을 원하지 않을 경우 0을 입력하세요.\r\n입고를 원하는 제품은 제품관리에서 정보를 미리 입력해야합니다.");
            this.addChild(obj.name, obj);

            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1740,980,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("Form_입고신청.xfdl", function() {
        this.btn_ipopup_onclick = function(obj,e)
        {
        	var objChildFrame = new ChildFrame();
            objChildFrame.init("chf_popup1"
                              , 0
                              , 0
                              , 532
                              , 338
                              , null
                              , null
                              , "FrameBase::Form_제품팝업.xfdl");

            objChildFrame.set_dragmovetype("all");
            objChildFrame.set_openalign("center middle");
        	objChildFrame.set_resizable(false);
            objChildFrame.set_overlaycolor("RGBA(196,196,196,0.5)")

            objChildFrame.showModal(this.getOwnerFrame()
                                  , null
                                  , this
                                  , "callbackpopup");
        };

        this.callbackpopup = function(strPopupID,strReturn)
        {
        	if(strReturn != null){
        		var str = strReturn.split("/");
        		this.edt_inum.set_value(str[0]);
        		this.edt_iname.set_value(str[1]);
        		this.edt_num.set_value(str[2]);
        		this.edt_name.set_value(str[3]);
        		this.edt_price.set_value(str[4]);
        		this.edt_ea.set_value(str[5]);
        	}
        };
        this.btn_add_onclick = function(obj,e)
        {
        	var i_num = this.edt_inum.value;
        	var i_name = this.edt_iname.value;
        	var b_num = this.edt_num.value;
        	var b_name = this.edt_name.value;
        	var price = this.edt_price.value;
        	var ea = this.edt_ea.value;
        	var sale = this.edt_sale.value;
        	var count = this.edt_icount.value;
        	var ddate = this.cal_deadline.value;

        	var svcid = "storing";
        	var svcurl = "Url::/storing";
        	var indataset = "";
        	var outdataset = "";
        	var parameter = "i_num=" + i_num + " i_name=" + i_name + " b_num=" + b_num + " b_name=" + b_name + " price=" + price + " ea=" + ea +
        	" sale=" + sale + " count=" + count + " ddate=" + ddate;
        	var svccallback = "cb_storing";

        	if(!i_num || !sale || !count || !ddate){
        		this.alert("모든 항목을 입력해주세요.");
        	}else{
        		this.transaction(svcid, svcurl, indataset, outdataset, parameter, svccallback);
        	}
        };

        this.cb_storing = function ()
        {
        	this.edt_sale.set_value();
        	this.edt_icount.set_value();
        	this.cal_deadline.set_value();
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.btn_add.addEventHandler("onclick",this.btn_add_onclick,this);
            this.btn_ipopup.addEventHandler("onclick",this.btn_ipopup_onclick,this);
        };

        this.loadIncludeScript("Form_입고신청.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
