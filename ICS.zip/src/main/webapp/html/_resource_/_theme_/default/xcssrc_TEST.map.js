﻿(function()
{
	return function()
	{
		nexacro._setCSSMaps(
		{
			"Static" :
			{
				"self" :
				{
					"enabled" :
					{
						"font" : nexacro.FontObject("normal 16pt/normal \"배달의민족 주아\""),
						"color" : nexacro.ColorObject("#000000")
					}
				}
			},
			"Button" :
			{
				"self" :
				{
					"enabled" :
					{
						"font" : nexacro.FontObject("normal 16pt/normal \"배달의민족 주아\"")
					}
				}
			},
			"Grid" :
			{
				"self" :
				{
					"enabled" :
					{
						"font" : nexacro.FontObject("normal 12pt/normal \"배달의민족 주아\"")
					}
				}
			},
			"Edit" :
			{
				"self" :
				{
					"enabled" :
					{
						"font" : nexacro.FontObject("normal 12pt/normal \"배달의민족 주아\"")
					}
				}
			}
		}
		);

		var imgcache = nexacro._getImageCacheMaps();
		
	};
}
)();
